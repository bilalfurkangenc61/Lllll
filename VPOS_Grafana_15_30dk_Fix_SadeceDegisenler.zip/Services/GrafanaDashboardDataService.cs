using System.Globalization;
using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using Microsoft.AspNetCore.WebUtilities;

namespace PayChainX.Services;

public sealed class GrafanaErrorFilter
{
    public string? Customer { get; set; }
    public string? Code { get; set; }
    public string? Source { get; set; }
    public string? Search { get; set; }
    public DateTime? From { get; set; }
    public DateTime? To { get; set; }
    public int Days { get; set; } = 30;
    public int Minutes { get; set; } = 0;
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 50;
    public string PanelGroup { get; set; } = "Errors";
}

public sealed class GrafanaErrorRow
{
    public DateTimeOffset? Timestamp { get; set; }
    public string TimestampText { get; set; } = "";
    public string Source { get; set; } = "";
    public string Customer { get; set; } = "";
    public string Code { get; set; } = "";
    public string Description { get; set; } = "";
    public string Transaction { get; set; } = "";
    public string Status { get; set; } = "";
    public decimal? Amount { get; set; }
    public long Count { get; set; } = 1;
    public string PanelTitle { get; set; } = "";
    public string GrafanaUrl { get; set; } = "";
    public string ElasticUrl { get; set; } = "";
    public Dictionary<string, string> Fields { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}

public sealed record GrafanaAggregate(string Key, long Count, decimal Amount = 0m);
public sealed record GrafanaErrorGroup(string Source, string Customer, string Code, string Description, long Count, decimal Amount, string GrafanaUrl, string ElasticUrl);

public sealed class GrafanaErrorDashboardResult
{
    public string DashboardTitle { get; set; } = "";
    public string DashboardUrl { get; set; } = "";
    public string DashboardUid { get; set; } = "";
    public string? Error { get; set; }
    public DateTimeOffset RefreshedAt { get; set; } = DateTimeOffset.Now;
    public GrafanaErrorFilter Filter { get; set; } = new();
    public List<GrafanaErrorRow> Rows { get; set; } = new();
    public List<GrafanaErrorGroup> Groups { get; set; } = new();
    public List<GrafanaAggregate> Customers { get; set; } = new();
    public List<GrafanaAggregate> Codes { get; set; } = new();
    public List<GrafanaAggregate> Sources { get; set; } = new();
    public List<GrafanaAggregate> Days { get; set; } = new();
    public long Total => Rows.Sum(x => Math.Max(1, x.Count));
    public int AffectedCustomers
    {
        get
        {
            var count = Rows
                .Where(x => !string.IsNullOrWhiteSpace(x.Customer))
                .Select(x => x.Customer)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .Count();

            // Grafana'nın "Canlı Hata Logları" paneli merchant alanını kolon olarak
            // döndürmeyebilir; merchant dashboard değişkeniyle filtreleniyorsa bunu 1 say.
            if (count == 0 && !string.IsNullOrWhiteSpace(Filter.Customer) &&
                !Filter.Customer.Equals("ALL", StringComparison.OrdinalIgnoreCase))
                return 1;

            return count;
        }
    }
}

public static class GrafanaUrlTools
{
    public static string BaseUrl(string url)
    {
        if (!Uri.TryCreate(url, UriKind.Absolute, out var uri)) return url.TrimEnd('/');
        var path = uri.AbsolutePath;
        var idx = path.IndexOf("/d/", StringComparison.OrdinalIgnoreCase);
        if (idx < 0) idx = path.IndexOf("/dashboard/", StringComparison.OrdinalIgnoreCase);
        var basePath = idx >= 0 ? path[..idx] : path.TrimEnd('/');
        var builder = new UriBuilder(uri.Scheme, uri.Host, uri.IsDefaultPort ? -1 : uri.Port, basePath);
        return builder.Uri.ToString().TrimEnd('/');
    }

    public static string? DashboardUid(string url)
    {
        if (!Uri.TryCreate(url, UriKind.Absolute, out var uri)) return null;
        var parts = uri.AbsolutePath.Split('/', StringSplitOptions.RemoveEmptyEntries);
        for (var i = 0; i < parts.Length - 1; i++)
        {
            if (string.Equals(parts[i], "d", StringComparison.OrdinalIgnoreCase)) return parts[i + 1];
        }
        return null;
    }

    public static string CleanDashboardUrl(string url)
    {
        if (!Uri.TryCreate(url, UriKind.Absolute, out var uri)) return url;
        var builder = new UriBuilder(uri) { Query = "" };
        return builder.Uri.ToString().TrimEnd('/');
    }
}

public sealed class GrafanaDashboardDataService
{
    private readonly IConfiguration _cfg;

    public GrafanaDashboardDataService(IConfiguration cfg) => _cfg = cfg;

    public async Task<GrafanaErrorDashboardResult> QueryAsync(ConnectionInfo connection, GrafanaErrorFilter filter, CancellationToken ct)
    {
        var result = new GrafanaErrorDashboardResult { Filter = filter, DashboardUrl = GrafanaUrlTools.CleanDashboardUrl(connection.GrafanaUrl) };
        if (string.IsNullOrWhiteSpace(connection.GrafanaUrl))
        {
            result.Error = "Grafana dashboard URL yapılandırılmadı.";
            return result;
        }

        var uid = GrafanaUrlTools.DashboardUid(connection.GrafanaUrl);
        if (string.IsNullOrWhiteSpace(uid))
        {
            result.Error = "Grafana ana adresi yerine ilgili dashboard URL'sini girin. URL içinde /d/{uid}/... bulunmalı.";
            return result;
        }

        result.DashboardUid = uid;
        var baseUrl = GrafanaUrlTools.BaseUrl(connection.GrafanaUrl);
        using var client = CreateClient(connection);
        var dashboardRoot = await GetDashboardAsync(client, baseUrl, uid, connection, ct);
        if (dashboardRoot is null)
        {
            result.Error = "Grafana dashboard okunamadı.";
            return result;
        }

        var dashboard = dashboardRoot["dashboard"] as JsonObject;
        result.DashboardTitle = dashboard?["title"]?.GetValue<string>() ?? "Grafana Dashboard";
        var allPanels = FlattenPanels(dashboard?["panels"] as JsonArray).ToList();
        var selected = SelectPanels(allPanels, filter).ToList();
        if (selected.Count == 0)
        {
            result.Error = $"'{filter.PanelGroup}' için uygun panel bulunamadı. appsettings.json içindeki GrafanaDashboard panel anahtar kelimelerini dashboard başlıklarına göre güncelleyin.";
            return result;
        }

        var (from, to) = ResolveRange(filter);
        var replacements = BuildReplacements(filter,connection.GrafanaUrl);
        var rows = new List<GrafanaErrorRow>();

        foreach (var panel in selected.Take(20))
        {
            ct.ThrowIfCancellationRequested();
            try
            {
                var panelRows = await QueryPanelAsync(client, baseUrl, connection.GrafanaUrl, panel, filter, from, to, replacements, ct);
                rows.AddRange(panelRows);
            }
            catch (Exception ex)
            {
                // Bir panel bozuksa tüm ekranı düşürmeyelim; hata bilgisini sonuçta gösterelim.
                result.Error = string.IsNullOrWhiteSpace(result.Error) ? ex.Message : result.Error + " | " + ex.Message;
            }
        }

        rows = Deduplicate(rows);
        rows = ApplyLocalFilters(rows, filter).ToList();
        result.Rows = rows.Any(x => x.Timestamp.HasValue)
            ? rows.OrderByDescending(x => x.Timestamp ?? DateTimeOffset.MinValue).ToList()
            : rows.OrderByDescending(x => x.Count).ToList();
        BuildAggregates(result);
        result.RefreshedAt = DateTimeOffset.Now;
        return result;
    }

    public string BuildGrafanaUrl(ConnectionInfo connection, GrafanaErrorFilter filter, int? panelId = null)
    {
        var url = GrafanaUrlTools.CleanDashboardUrl(connection.GrafanaUrl);
        var (from, to) = ResolveRange(filter);
        var query = ExistingDashboardQuery(connection.GrafanaUrl);
        query["from"] = new DateTimeOffset(from).ToUnixTimeMilliseconds().ToString(CultureInfo.InvariantCulture);
        query["to"] = new DateTimeOffset(to).ToUnixTimeMilliseconds().ToString(CultureInfo.InvariantCulture);
        AddGrafanaVariable(query, "Customer", filter.Customer);
        AddGrafanaVariable(query, "Code", filter.Code);
        AddGrafanaVariable(query, "Source", filter.Source);
        AddGrafanaVariable(query, "Search", filter.Search);
        if (panelId.HasValue) query["viewPanel"] = panelId.Value.ToString(CultureInfo.InvariantCulture);
        return QueryHelpers.AddQueryString(url, query.Where(x => !string.IsNullOrWhiteSpace(x.Value)).ToDictionary(x => x.Key, x => x.Value!));
    }

    private static (DateTime From, DateTime To) ResolveRange(GrafanaErrorFilter filter)
    {
        var to = filter.To ?? DateTime.Now;
        DateTime from;

        if (filter.From.HasValue)
        {
            from = filter.From.Value;
        }
        else if (filter.Minutes > 0)
        {
            var minutes = Math.Clamp(filter.Minutes, 1, 10080);
            from = to.AddMinutes(-minutes);
        }
        else
        {
            from = to.AddDays(-Math.Clamp(filter.Days, 1, 365));
        }

        if (to < from)
            (from, to) = (to, from);

        return (from, to);
    }

    private void AddGrafanaVariable(Dictionary<string, string?> query, string name, string? value)
    {
        if (string.IsNullOrWhiteSpace(value) || string.Equals(value, "ALL", StringComparison.OrdinalIgnoreCase)) return;
        var configured = _cfg[$"GrafanaDashboard:Variables:{name}"];
        if (!string.IsNullOrWhiteSpace(configured)) query["var-" + configured] = value;
    }

    private HttpClient CreateClient(ConnectionInfo connection)
    {
        var handler = new HttpClientHandler
        {
            CookieContainer = new CookieContainer(),
            UseCookies = true,
            AllowAutoRedirect = true
        };
        var client = new HttpClient(handler) { Timeout = TimeSpan.FromSeconds(30) };
        if (!string.IsNullOrWhiteSpace(connection.GrafanaUser))
        {
            var raw = Convert.ToBase64String(Encoding.UTF8.GetBytes(connection.GrafanaUser + ":" + connection.GrafanaPassword));
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", raw);
        }
        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        if(Uri.TryCreate(connection.GrafanaUrl,UriKind.Absolute,out var grafanaUri))
        {
            var parsed=QueryHelpers.ParseQuery(grafanaUri.Query);
            if(parsed.TryGetValue("orgId",out var orgId)&&!string.IsNullOrWhiteSpace(orgId.ToString()))
                client.DefaultRequestHeaders.TryAddWithoutValidation("X-Grafana-Org-Id",orgId.ToString());
        }
        return client;
    }

    private async Task<JsonObject?> GetDashboardAsync(HttpClient client, string baseUrl, string uid, ConnectionInfo connection, CancellationToken ct)
    {
        var url = baseUrl + "/api/dashboards/uid/" + Uri.EscapeDataString(uid);
        using var response = await client.GetAsync(url, ct);
        if (response.IsSuccessStatusCode)
            return JsonNode.Parse(await response.Content.ReadAsStringAsync(ct)) as JsonObject;

        if (response.StatusCode is HttpStatusCode.Unauthorized or HttpStatusCode.Forbidden)
        {
            client.DefaultRequestHeaders.Authorization = null;
            using var login = new HttpRequestMessage(HttpMethod.Post, baseUrl + "/login")
            {
                Content = new StringContent(JsonSerializer.Serialize(new { user = connection.GrafanaUser, password = connection.GrafanaPassword }), Encoding.UTF8, "application/json")
            };
            using var loginResponse = await client.SendAsync(login, ct);
            if (loginResponse.IsSuccessStatusCode || (int)loginResponse.StatusCode is >= 300 and < 400)
            {
                using var retry = await client.GetAsync(url, ct);
                if (retry.IsSuccessStatusCode)
                    return JsonNode.Parse(await retry.Content.ReadAsStringAsync(ct)) as JsonObject;
            }
        }

        throw new InvalidOperationException($"Grafana dashboard API HTTP {(int)response.StatusCode}. Kullanıcı yetkisini ve dashboard URL'sini kontrol edin.");
    }

    private IEnumerable<JsonObject> FlattenPanels(JsonArray? panels)
    {
        if (panels is null) yield break;
        foreach (var node in panels)
        {
            if (node is not JsonObject panel) continue;
            yield return panel;
            if (panel["panels"] is JsonArray nested)
                foreach (var child in FlattenPanels(nested)) yield return child;
        }
    }

    private IEnumerable<JsonObject> SelectPanels(IEnumerable<JsonObject> panels, GrafanaErrorFilter filter)
    {
        var queryable = panels
            .Where(p => p["targets"] is JsonArray a && a.Count > 0)
            .ToList();

        // Hata ekranında bütün "hata" geçen panelleri sorgulamak yanlış sonuç üretiyordu.
        // Özellikle stat/time-series panelleri tablo satırı gibi parse edilince 50.000 satır,
        // firma=0 ve ISO '-' gibi sahte sonuçlar oluşuyordu.
        // Önce gerçek tablo panelini seç: "Canlı Hata Logları".
        if (filter.PanelGroup.Equals("Errors", StringComparison.OrdinalIgnoreCase))
        {
            static string N(string? value)
            {
                value ??= string.Empty;
                return Regex.Replace(
                    value.ToLowerInvariant()
                        .Replace("ı", "i")
                        .Replace("ü", "u")
                        .Replace("ö", "o")
                        .Replace("ş", "s")
                        .Replace("ç", "c")
                        .Replace("ğ", "g"),
                    "[^a-z0-9]", "");
            }

            var preferred = queryable.Where(p =>
            {
                var title = N(p["title"]?.ToString());
                return title.Contains("canlihatalog", StringComparison.Ordinal) ||
                       title.Contains("hatalog", StringComparison.Ordinal) ||
                       title.Contains("errorlog", StringComparison.Ordinal);
            }).ToList();

            if (preferred.Count > 0)
            {
                var sourceKeywords = SourceKeywords(filter.Source);
                if (sourceKeywords.Length == 0) return preferred;

                var sourceFiltered = preferred.Where(p =>
                {
                    var text = p.ToJsonString();
                    return sourceKeywords.Any(k => text.Contains(k, StringComparison.OrdinalIgnoreCase));
                }).ToList();

                // Dashboard tek ortak "Canlı Hata Logları" paneli kullanıyorsa source filtresi
                // panel başlığında geçmez; o durumda paneli kaybetme.
                return sourceFiltered.Count > 0 ? sourceFiltered : preferred;
            }
        }

        var groupKeywords = _cfg.GetSection($"GrafanaDashboard:PanelKeywords:{filter.PanelGroup}").Get<string[]>() ?? Array.Empty<string>();
        if (groupKeywords.Length == 0)
        {
            groupKeywords = filter.PanelGroup.Equals("Commissions", StringComparison.OrdinalIgnoreCase)
                ? new[] { "komisyon", "kesinti", "commission", "fee" }
                : filter.PanelGroup.Equals("Transactions", StringComparison.OrdinalIgnoreCase)
                    ? new[] { "işlem", "islem", "transaction", "payment", "satış", "satis", "sale" }
                    : new[] { "hata", "error", "response", "decline", "banksoft", "bankacard", "coxec" };
        }

        var sourceKeys = SourceKeywords(filter.Source);
        var selected = queryable.Where(p =>
        {
            var text = (p["title"]?.ToString() ?? "") + " " + p.ToJsonString();
            var groupMatch = groupKeywords.Any(k => text.Contains(k, StringComparison.OrdinalIgnoreCase));
            var sourceMatch = sourceKeys.Length == 0 || sourceKeys.Any(k => text.Contains(k, StringComparison.OrdinalIgnoreCase));
            return groupMatch && sourceMatch;
        }).ToList();

        if (selected.Count == 0 && sourceKeys.Length > 0)
            selected = queryable.Where(p => sourceKeys.Any(k => p.ToJsonString().Contains(k, StringComparison.OrdinalIgnoreCase))).ToList();
        if (selected.Count == 0)
            selected = queryable.Where(p => groupKeywords.Any(k => (p["title"]?.ToString() ?? "").Contains(k, StringComparison.OrdinalIgnoreCase))).ToList();

        return selected;
    }

    private string[] SourceKeywords(string? source)
    {
        if (string.IsNullOrWhiteSpace(source) || source.Equals("ALL", StringComparison.OrdinalIgnoreCase)) return Array.Empty<string>();
        var configured = _cfg.GetSection($"GrafanaDashboard:SourceKeywords:{source.ToUpperInvariant()}").Get<string[]>();
        return configured?.Length > 0 ? configured : new[] { source };
    }

    private Dictionary<string, string> BuildReplacements(GrafanaErrorFilter filter,string dashboardUrl)
    {
        var map = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        if(Uri.TryCreate(dashboardUrl,UriKind.Absolute,out var dashboardUri))
        {
            foreach(var pair in QueryHelpers.ParseQuery(dashboardUri.Query))
            {
                if(pair.Key.StartsWith("var-",StringComparison.OrdinalIgnoreCase)&&!string.IsNullOrWhiteSpace(pair.Value.ToString()))
                    map[pair.Key[4..]]=pair.Value.ToString();
            }
        }
        void Add(string name, string? value)
        {
            var variable = _cfg[$"GrafanaDashboard:Variables:{name}"];
            if (!string.IsNullOrWhiteSpace(variable) && !string.IsNullOrWhiteSpace(value) && !value.Equals("ALL",StringComparison.OrdinalIgnoreCase)) map[variable] = value;
        }
        Add("Customer", filter.Customer);
        Add("Code", filter.Code);
        Add("Source", filter.Source);
        Add("Search", filter.Search);
        return map;
    }

    private async Task<List<GrafanaErrorRow>> QueryPanelAsync(HttpClient client, string baseUrl, string dashboardUrl, JsonObject panel, GrafanaErrorFilter filter, DateTime from, DateTime to, Dictionary<string, string> replacements, CancellationToken ct)
    {
        var targets = panel["targets"] as JsonArray;
        if (targets is null || targets.Count == 0) return new();
        var panelDatasource = panel["datasource"]?.DeepClone();
        var queries = new JsonArray();
        int? panelId=null;
        if(panel["id"] is JsonValue panelIdValue && panelIdValue.TryGetValue<int>(out var parsedPanelId)) panelId=parsedPanelId;
        var panelTitle = panel["title"]?.ToString() ?? "Grafana Panel";
        var localReplacements=new Dictionary<string,string>(replacements,StringComparer.OrdinalIgnoreCase);
        var codeVariable=_cfg["GrafanaDashboard:Variables:Code"];
        if(!string.IsNullOrWhiteSpace(codeVariable) && localReplacements.TryGetValue(codeVariable,out var requestedCode) && panelTitle.Contains("banksoft",StringComparison.OrdinalIgnoreCase))
            localReplacements[codeVariable]=NormalizeRawCode(requestedCode,"BANKSOFT");
        var index = 0;

        foreach (var targetNode in targets)
        {
            if (targetNode is not JsonObject target) continue;
            if (target["hide"] is JsonValue hideValue && hideValue.TryGetValue<bool>(out var hidden) && hidden) continue;
            var clone = target.DeepClone() as JsonObject ?? new JsonObject();
            SubstituteNode(clone, localReplacements);
            if (clone["datasource"] is null && panelDatasource is not null) clone["datasource"] = panelDatasource.DeepClone();
            clone["refId"] = $"PX{panelId ?? 0}_{index++}";
            clone["maxDataPoints"] = 5000;
            clone["intervalMs"] = 60000;
            queries.Add(clone);
        }

        if (queries.Count == 0) return new();
        var fromMs = new DateTimeOffset(from).ToUnixTimeMilliseconds().ToString(CultureInfo.InvariantCulture);
        var toMs = new DateTimeOffset(to).ToUnixTimeMilliseconds().ToString(CultureInfo.InvariantCulture);
        var body = new JsonObject { ["from"] = fromMs, ["to"] = toMs, ["queries"] = queries };
        using var request = new HttpRequestMessage(HttpMethod.Post, baseUrl + "/api/ds/query")
        {
            Content = new StringContent(body.ToJsonString(), Encoding.UTF8, "application/json")
        };
        using var response = await client.SendAsync(request, ct);
        var payload = await response.Content.ReadAsStringAsync(ct);
        if (!response.IsSuccessStatusCode)
            throw new InvalidOperationException($"Grafana '{panelTitle}' sorgusu HTTP {(int)response.StatusCode}. Dashboard datasource yetkisini kontrol edin.");

        var root = JsonNode.Parse(payload) as JsonObject;
        var rows = ParseFrames(root, panelTitle, panel, filter, dashboardUrl, panelId, from, to);
        return rows;
    }

    private List<GrafanaErrorRow> ParseFrames(JsonObject? root, string panelTitle, JsonObject panel, GrafanaErrorFilter filter, string dashboardUrl, int? panelId, DateTime from, DateTime to)
    {
        var rows = new List<GrafanaErrorRow>();
        if (root?["results"] is not JsonObject results) return rows;
        var links = ExtractLinks(panel).ToList();

        foreach (var resultEntry in results)
        {
            if (resultEntry.Value is not JsonObject result || result["frames"] is not JsonArray frames) continue;

            foreach (var frameNode in frames)
            {
                if (frameNode is not JsonObject frame) continue;
                var fields = frame["schema"]?["fields"] as JsonArray;
                var values = frame["data"]?["values"] as JsonArray;
                if (fields is null || values is null || fields.Count == 0 || values.Count == 0) continue;

                var names = fields.Select(FieldName).ToList();

                // Error ekranında yalnızca hata tablosu niteliğindeki frame'leri kabul et.
                // "Toplam API Çağrımı", "Başarısız API Cevabı" ve zaman serileri artık
                // yanlışlıkla log satırı sayılmıyor.
                if (filter.PanelGroup.Equals("Errors", StringComparison.OrdinalIgnoreCase) &&
                    !LooksLikeErrorTable(names))
                    continue;

                var rowCount = values.OfType<JsonArray>().Select(v => v.Count).DefaultIfEmpty(0).Max();
                for (var rowIndex = 0; rowIndex < rowCount; rowIndex++)
                {
                    var map = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                    for (var col = 0; col < Math.Min(names.Count, values.Count); col++)
                    {
                        if (values[col] is not JsonArray column || rowIndex >= column.Count) continue;
                        var value = NodeText(column[rowIndex]);
                        if (!string.IsNullOrWhiteSpace(names[col])) map[names[col]] = value;
                    }

                    if (map.Count == 0) continue;
                    var row = MapRow(map, panelTitle, filter);

                    // Hata panelinde code/description olmayan frame gerçek hata satırı değildir.
                    if (filter.PanelGroup.Equals("Errors", StringComparison.OrdinalIgnoreCase) &&
                        string.IsNullOrWhiteSpace(row.Code) && string.IsNullOrWhiteSpace(row.Description))
                        continue;

                    row.Fields = map;
                    var rowFilter = new GrafanaErrorFilter
                    {
                        Customer = string.IsNullOrWhiteSpace(row.Customer) ? filter.Customer : row.Customer,
                        Code = row.Code,
                        Source = row.Source,
                        From = filter.From,
                        To = filter.To,
                        Days = filter.Days
                    };
                    row.GrafanaUrl = BuildGrafanaUrlFromDashboard(dashboardUrl, rowFilter, panelId, from, to);
                    row.ElasticUrl = ResolveElasticLink(links, row, dashboardUrl);
                    rows.Add(row);
                }
            }
        }

        return rows;
    }

    private static bool LooksLikeErrorTable(IReadOnlyCollection<string> names)
    {
        static string N(string value) => Regex.Replace(
            value.ToLowerInvariant()
                .Replace("ı", "i")
                .Replace("ü", "u")
                .Replace("ö", "o")
                .Replace("ş", "s")
                .Replace("ç", "c")
                .Replace("ğ", "g"),
            "[^a-z0-9]", "");

        var normalized = names.Where(x => !string.IsNullOrWhiteSpace(x)).Select(N).ToArray();
        var hasCode = normalized.Any(x =>
            x.Contains("hatakodu", StringComparison.Ordinal) ||
            x.Contains("responsecode", StringComparison.Ordinal) ||
            x.Contains("resultcode", StringComparison.Ordinal) ||
            x == "code" || x == "rc");
        var hasMessage = normalized.Any(x =>
            x.Contains("message", StringComparison.Ordinal) ||
            x.Contains("aciklama", StringComparison.Ordinal) ||
            x.Contains("description", StringComparison.Ordinal) ||
            x.Contains("error", StringComparison.Ordinal));
        var hasCount = normalized.Any(x =>
            x.Contains("hatasayisi", StringComparison.Ordinal) ||
            x.Contains("count", StringComparison.Ordinal) ||
            x.Contains("adet", StringComparison.Ordinal));

        return hasCode || (hasMessage && hasCount);
    }

    private string FieldName(JsonNode? node)
    {
        if (node is not JsonObject field) return "";
        var display = field["config"]?["displayName"]?.ToString();
        if (!string.IsNullOrWhiteSpace(display)) return display;
        var ds = field["config"]?["displayNameFromDS"]?.ToString();
        if (!string.IsNullOrWhiteSpace(ds)) return ds;
        return field["name"]?.ToString() ?? "";
    }

    private GrafanaErrorRow MapRow(Dictionary<string, string> map, string panelTitle, GrafanaErrorFilter filter)
    {
        var timestamp = Find(map, "Timestamp", new[] { "@timestamp", "timestamp", "time", "tarih", "date", "datetime", "zaman" });
        var customer = Find(map, "Customer", new[] { "customer", "firma", "merchant", "merchantName", "uyeisyeri", "üye işyeri", "isyeri", "client", "company" });
        var rawCode = Find(map, "Code", new[] { "hata kodu (proc/result)", "proc/result", "responsecode", "code", "hatakodu", "hata kodu", "errorcode", "rc", "resultcode" });
        var source = Find(map, "Source", new[] { "source", "service", "provider", "kaynak", "channel", "host", "switch" });
        var transaction = Find(map, "Transaction", new[] { "transactionid", "transaction", "islemno", "işlem no", "orderid", "invoiceid", "rrn", "stan" });
        var status = Find(map, "Status", new[] { "status", "durum", "result", "state" });
        var description = Find(map, "Description", new[] { "message", "description", "error", "hata açıklaması", "hataaciklama", "aciklama", "açıklama" });
        var amountText = Find(map, "Amount", new[] { "amount", "tutar", "total", "price" });
        var countText = Find(map, "Count", new[] { "hata sayısı", "hata sayisi", "count", "adet", "işlem adedi", "islemadedi", "value", "totalcount" });

        var parsed = ParseSourceAndCode(rawCode, source, panelTitle);
        source = parsed.Source;
        var code = parsed.Code;

        // Grafana'nın mesajını her zaman öncelikli tut. Sözlük yalnızca mesaj yoksa devreye girer.
        if (string.IsNullOrWhiteSpace(description))
            description = !string.IsNullOrWhiteSpace(parsed.InlineDescription)
                ? parsed.InlineDescription
                : CodeCatalog.Describe(source, code);

        var dt = ParseDate(timestamp);
        var count = ParseLong(countText);
        if (count <= 0) count = 1;

        return new GrafanaErrorRow
        {
            Timestamp = dt,
            TimestampText = dt?.LocalDateTime.ToString("dd.MM.yyyy HH:mm:ss") ?? timestamp,
            Source = source,
            Customer = string.IsNullOrWhiteSpace(customer) && !string.IsNullOrWhiteSpace(filter.Customer) &&
                       !filter.Customer.Equals("ALL", StringComparison.OrdinalIgnoreCase)
                ? filter.Customer
                : customer,
            Code = code,
            Description = description,
            Transaction = transaction,
            Status = status,
            Amount = ParseDecimal(amountText),
            Count = count,
            PanelTitle = panelTitle
        };
    }

    private static (string Source, string Code, string InlineDescription) ParseSourceAndCode(string? rawCode, string? rawSource, string panelTitle)
    {
        var value = (rawCode ?? string.Empty).Trim();
        var source = CanonicalSourceStatic(rawSource ?? string.Empty);
        var inlineDescription = string.Empty;

        // Örn: "VPOS: VB18 (OriginalTransactionNotFound)" / "BANKA: 51" / "BANKSOFT: 005"
        var prefixed = Regex.Match(value,
            @"^\s*\*?\s*(?<source>BANKSOFT|BANKACARD|BANKKART|COXEC|CODEC|BANKA|ISO8583|VPOS)\s*:\s*(?<code>[A-Z0-9]+)(?:\s*\((?<desc>[^)]+)\))?",
            RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
        if (prefixed.Success)
        {
            source = CanonicalSourceStatic(prefixed.Groups["source"].Value);
            value = prefixed.Groups["code"].Value;
            inlineDescription = prefixed.Groups["desc"].Value.Trim();
        }
        else
        {
            // "*VB18*", "*51", "005" gibi Canlı Hata Logları değerleri.
            value = value.Trim().Trim('*').Trim();
            var codeMatch = Regex.Match(value, @"(?<code>VB\d+|[A-Z]{1,8}\d+|\d{1,4})", RegexOptions.IgnoreCase);
            if (codeMatch.Success) value = codeMatch.Groups["code"].Value;
        }

        if (string.IsNullOrWhiteSpace(source))
        {
            if (value.StartsWith("VB", StringComparison.OrdinalIgnoreCase))
                source = "VPOS";
            else if (panelTitle.Contains("banksoft", StringComparison.OrdinalIgnoreCase))
                source = "BANKSOFT";
            else if (panelTitle.Contains("bankacard", StringComparison.OrdinalIgnoreCase) || panelTitle.Contains("bankkart", StringComparison.OrdinalIgnoreCase))
                source = "BANKACARD";
            else if (panelTitle.Contains("coxec", StringComparison.OrdinalIgnoreCase) || panelTitle.Contains("codec", StringComparison.OrdinalIgnoreCase))
                source = "COXEC";
            else if (Regex.IsMatch(value, @"^\d{1,3}$"))
                source = "ISO8583";
        }

        return (source, NormalizeRawCode(value, source), inlineDescription);
    }

    private static string CanonicalSourceStatic(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return string.Empty;
        if (value.Contains("banksoft", StringComparison.OrdinalIgnoreCase)) return "BANKSOFT";
        if (value.Contains("bankacard", StringComparison.OrdinalIgnoreCase) || value.Contains("bankkart", StringComparison.OrdinalIgnoreCase)) return "BANKACARD";
        if (value.Contains("coxec", StringComparison.OrdinalIgnoreCase) || value.Contains("codec", StringComparison.OrdinalIgnoreCase)) return "COXEC";
        if (value.Contains("iso8583", StringComparison.OrdinalIgnoreCase) || value.Contains("iso 8583", StringComparison.OrdinalIgnoreCase) || value.Equals("BANKA", StringComparison.OrdinalIgnoreCase)) return "ISO8583";
        if (value.Contains("vpos", StringComparison.OrdinalIgnoreCase)) return "VPOS";
        return value.Trim().ToUpperInvariant();
    }

    private string Find(Dictionary<string, string> map, string configName, string[] defaults)
    {
        var aliases = _cfg.GetSection($"GrafanaDashboard:FieldAliases:{configName}").Get<string[]>() ?? defaults;
        foreach (var alias in aliases)
        {
            var direct = map.FirstOrDefault(x => KeyMatch(x.Key, alias));
            if (!string.IsNullOrWhiteSpace(direct.Key) && !string.IsNullOrWhiteSpace(direct.Value)) return direct.Value;
        }
        return "";
    }

    private static bool KeyMatch(string key, string alias)
    {
        static string N(string s) => Regex.Replace(s.ToLowerInvariant().Replace("ı", "i").Replace("ü", "u").Replace("ö", "o").Replace("ş", "s").Replace("ç", "c").Replace("ğ", "g"), "[^a-z0-9]", "");
        var k = N(key); var a = N(alias);
        return k == a || k.Contains(a, StringComparison.Ordinal) || a.Contains(k, StringComparison.Ordinal);
    }

    private string CanonicalSource(string value) => CanonicalSourceStatic(value);

    private static string NormalizeRawCode(string code, string source)
    {
        if (string.IsNullOrWhiteSpace(code)) return string.Empty;

        var cleaned = code.Trim().ToUpperInvariant()
            .Replace("ISO8583-", string.Empty)
            .Replace("BANKSOFT-", string.Empty)
            .Trim('*')
            .Trim();

        var token = Regex.Match(cleaned, @"VB\d+|[A-Z]{1,8}\d+|\d{1,4}", RegexOptions.IgnoreCase).Value;
        if (!string.IsNullOrWhiteSpace(token)) cleaned = token.ToUpperInvariant();

        // VPOS uygulama kodları (VB18 vb.) ISO koduna çevrilmez.
        if (cleaned.StartsWith("VB", StringComparison.OrdinalIgnoreCase))
            return cleaned;

        if (Regex.IsMatch(cleaned, @"^\d+$"))
        {
            if (source.Equals("BANKSOFT", StringComparison.OrdinalIgnoreCase) && cleaned.Length <= 3)
                return cleaned.PadLeft(3, '0');

            if (cleaned.Length <= 3 && int.TryParse(cleaned, out var n))
                return n.ToString("00", CultureInfo.InvariantCulture);
        }

        return cleaned;
    }

    private static DateTimeOffset? ParseDate(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;
        if (long.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var epoch))
        {
            try { return epoch > 10_000_000_000L ? DateTimeOffset.FromUnixTimeMilliseconds(epoch) : DateTimeOffset.FromUnixTimeSeconds(epoch); } catch { }
        }
        if (DateTimeOffset.TryParse(value, CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal, out var dto)) return dto;
        if (DateTimeOffset.TryParse(value, new CultureInfo("tr-TR"), DateTimeStyles.AssumeLocal, out dto)) return dto;
        return null;
    }

    private static decimal? ParseDecimal(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;
        var cleaned = Regex.Replace(value, "[^0-9,.-]", "");
        if (decimal.TryParse(cleaned, NumberStyles.Any, new CultureInfo("tr-TR"), out var tr)) return tr;
        if (decimal.TryParse(cleaned, NumberStyles.Any, CultureInfo.InvariantCulture, out var inv)) return inv;
        return null;
    }

    private static long ParseLong(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return 0;
        var cleaned = Regex.Replace(value, "[^0-9-]", "");
        return long.TryParse(cleaned, out var n) ? n : 0;
    }

    private static string NodeText(JsonNode? node)
    {
        if (node is null) return "";
        if (node is JsonValue value)
        {
            if (value.TryGetValue<string>(out var s)) return s ?? "";
            if (value.TryGetValue<long>(out var l)) return l.ToString(CultureInfo.InvariantCulture);
            if (value.TryGetValue<double>(out var d)) return d.ToString(CultureInfo.InvariantCulture);
            if (value.TryGetValue<decimal>(out var m)) return m.ToString(CultureInfo.InvariantCulture);
            if (value.TryGetValue<bool>(out var b)) return b ? "true" : "false";
        }
        return node.ToJsonString();
    }

    private void SubstituteNode(JsonNode node, Dictionary<string, string> replacements)
    {
        if (node is JsonObject obj)
        {
            foreach (var key in obj.Select(x => x.Key).ToList())
            {
                var child = obj[key];
                if (child is JsonValue v && v.TryGetValue<string>(out var s) && s is not null)
                {
                    foreach (var pair in replacements)
                    {
                        s = s.Replace("${" + pair.Key + "}", pair.Value, StringComparison.OrdinalIgnoreCase)
                             .Replace("$" + pair.Key, pair.Value, StringComparison.OrdinalIgnoreCase);
                    }
                    obj[key] = s;
                }
                else if (child is not null) SubstituteNode(child, replacements);
            }
        }
        else if (node is JsonArray array)
        {
            foreach (var child in array) if (child is not null) SubstituteNode(child, replacements);
        }
    }

    private IEnumerable<(string Title, string Url)> ExtractLinks(JsonNode node)
    {
        if (node is JsonObject obj)
        {
            if (obj["url"] is JsonValue urlValue && urlValue.TryGetValue<string>(out var url) && !string.IsNullOrWhiteSpace(url))
            {
                var title = obj["title"]?.ToString() ?? "Detay";
                if (url.Contains("http", StringComparison.OrdinalIgnoreCase) || url.Contains("kibana", StringComparison.OrdinalIgnoreCase) || url.Contains("elastic", StringComparison.OrdinalIgnoreCase) || url.Contains("${", StringComparison.Ordinal))
                    yield return (title, url);
            }
            foreach (var child in obj.Select(x => x.Value)) if (child is not null) foreach (var link in ExtractLinks(child)) yield return link;
        }
        else if (node is JsonArray array)
        {
            foreach (var child in array) if (child is not null) foreach (var link in ExtractLinks(child)) yield return link;
        }
    }

    private string ResolveElasticLink(IEnumerable<(string Title, string Url)> links, GrafanaErrorRow row, string dashboardUrl)
    {
        var preferred = links.FirstOrDefault(x => x.Url.Contains("kibana", StringComparison.OrdinalIgnoreCase) || x.Url.Contains("elastic", StringComparison.OrdinalIgnoreCase));
        if (string.IsNullOrWhiteSpace(preferred.Url)) preferred = links.FirstOrDefault();
        if (string.IsNullOrWhiteSpace(preferred.Url)) return "";
        var url = preferred.Url;
        foreach (var field in row.Fields)
        {
            url = url.Replace("${__data.fields[\"" + field.Key + "\"]}", Uri.EscapeDataString(field.Value), StringComparison.OrdinalIgnoreCase)
                     .Replace("${__data.fields['" + field.Key + "']}", Uri.EscapeDataString(field.Value), StringComparison.OrdinalIgnoreCase)
                     .Replace("${__data.fields." + field.Key + "}", Uri.EscapeDataString(field.Value), StringComparison.OrdinalIgnoreCase);
        }
        url = url.Replace("${__value.raw}", Uri.EscapeDataString(!string.IsNullOrWhiteSpace(row.Transaction) ? row.Transaction : row.Code), StringComparison.OrdinalIgnoreCase);
        if (Uri.TryCreate(url, UriKind.Absolute, out _)) return url;
        if (Uri.TryCreate(GrafanaUrlTools.BaseUrl(dashboardUrl) + "/", UriKind.Absolute, out var baseUri) && Uri.TryCreate(baseUri, url, out var absolute)) return absolute.ToString();
        return "";
    }

    private string BuildGrafanaUrlFromDashboard(string dashboardUrl, GrafanaErrorFilter filter, int? panelId, DateTime from, DateTime to)
    {
        var clean = GrafanaUrlTools.CleanDashboardUrl(dashboardUrl);
        var query = ExistingDashboardQuery(dashboardUrl);
        query["from"] = new DateTimeOffset(from).ToUnixTimeMilliseconds().ToString(CultureInfo.InvariantCulture);
        query["to"] = new DateTimeOffset(to).ToUnixTimeMilliseconds().ToString(CultureInfo.InvariantCulture);
        void Add(string n, string? v)
        {
            if (string.IsNullOrWhiteSpace(v) || v.Equals("ALL", StringComparison.OrdinalIgnoreCase)) return;
            var variable = _cfg[$"GrafanaDashboard:Variables:{n}"];
            if (!string.IsNullOrWhiteSpace(variable)) query["var-" + variable] = v;
        }
        Add("Customer", filter.Customer); Add("Code", filter.Code); Add("Source", filter.Source); Add("Search", filter.Search);
        if (panelId.HasValue) query["viewPanel"] = panelId.Value.ToString(CultureInfo.InvariantCulture);
        return QueryHelpers.AddQueryString(clean, query.Where(x => !string.IsNullOrWhiteSpace(x.Value)).ToDictionary(x => x.Key, x => x.Value!));
    }

    private static Dictionary<string,string?> ExistingDashboardQuery(string dashboardUrl)
    {
        var query=new Dictionary<string,string?>(StringComparer.OrdinalIgnoreCase);
        if(!Uri.TryCreate(dashboardUrl,UriKind.Absolute,out var uri))return query;
        foreach(var pair in QueryHelpers.ParseQuery(uri.Query))
        {
            if(pair.Key.Equals("from",StringComparison.OrdinalIgnoreCase)||pair.Key.Equals("to",StringComparison.OrdinalIgnoreCase)||pair.Key.Equals("viewPanel",StringComparison.OrdinalIgnoreCase))continue;
            query[pair.Key]=pair.Value.ToString();
        }
        return query;
    }

    private static List<GrafanaErrorRow> Deduplicate(IEnumerable<GrafanaErrorRow> rows)
    {
        return rows.GroupBy(x => string.Join("|", x.TimestampText, x.Source, x.Customer, x.Code, x.Transaction, x.PanelTitle, x.Count), StringComparer.OrdinalIgnoreCase).Select(g => g.First()).ToList();
    }

    private static IEnumerable<GrafanaErrorRow> ApplyLocalFilters(IEnumerable<GrafanaErrorRow> rows, GrafanaErrorFilter filter)
    {
        var query = rows;
        if (!string.IsNullOrWhiteSpace(filter.Customer)) query = query.Where(x => x.Customer.Contains(filter.Customer, StringComparison.OrdinalIgnoreCase));
        if (!string.IsNullOrWhiteSpace(filter.Code))
        {
            var code = Regex.Replace(filter.Code, "[^0-9A-Za-z]", "");
            query = query.Where(x => Regex.Replace(x.Code, "[^0-9A-Za-z]", "").EndsWith(code, StringComparison.OrdinalIgnoreCase));
        }
        if (!string.IsNullOrWhiteSpace(filter.Source) && !filter.Source.Equals("ALL", StringComparison.OrdinalIgnoreCase)) query = query.Where(x => x.Source.Contains(filter.Source, StringComparison.OrdinalIgnoreCase));
        if (!string.IsNullOrWhiteSpace(filter.Search))
        {
            var q = filter.Search.Trim();
            query = query.Where(x => x.Customer.Contains(q, StringComparison.OrdinalIgnoreCase) || x.Code.Contains(q, StringComparison.OrdinalIgnoreCase) || x.Description.Contains(q, StringComparison.OrdinalIgnoreCase) || x.Transaction.Contains(q, StringComparison.OrdinalIgnoreCase) || x.Source.Contains(q, StringComparison.OrdinalIgnoreCase) || x.Status.Contains(q, StringComparison.OrdinalIgnoreCase) || x.Fields.Any(f => f.Value.Contains(q, StringComparison.OrdinalIgnoreCase)));
        }
        return query;
    }

    private static void BuildAggregates(GrafanaErrorDashboardResult result)
    {
        static List<GrafanaAggregate> Agg(IEnumerable<GrafanaErrorRow> rows, Func<GrafanaErrorRow, string> key) => rows
            .Where(x => !string.IsNullOrWhiteSpace(key(x)))
            .GroupBy(key, StringComparer.OrdinalIgnoreCase)
            .Select(g => new GrafanaAggregate(g.Key, g.Sum(x => Math.Max(1, x.Count)), g.Sum(x => x.Amount ?? 0m)))
            .OrderByDescending(x => x.Count).ToList();

        result.Customers = Agg(result.Rows, x => x.Customer);
        result.Codes = Agg(result.Rows, x => x.Code);
        result.Sources = Agg(result.Rows, x => x.Source);
        result.Days = result.Rows.Where(x => x.Timestamp.HasValue)
            .GroupBy(x => x.Timestamp!.Value.LocalDateTime.Date)
            .Select(g => new GrafanaAggregate(g.Key.ToString("dd.MM.yyyy"), g.Sum(x => Math.Max(1, x.Count)), g.Sum(x => x.Amount ?? 0m)))
            .OrderByDescending(x => DateTime.ParseExact(x.Key, "dd.MM.yyyy", CultureInfo.InvariantCulture)).ToList();
        result.Groups = result.Rows
            .GroupBy(x => string.Join("\u001f", x.Source, x.Customer, x.Code, x.Description), StringComparer.OrdinalIgnoreCase)
            .Select(g =>
            {
                var first = g.First();
                return new GrafanaErrorGroup(first.Source, first.Customer, first.Code, first.Description, g.Sum(x => Math.Max(1, x.Count)), g.Sum(x => x.Amount ?? 0m), first.GrafanaUrl, g.Select(x => x.ElasticUrl).FirstOrDefault(x => !string.IsNullOrWhiteSpace(x)) ?? "");
            })
            .OrderByDescending(x => x.Count).ToList();
    }
}
