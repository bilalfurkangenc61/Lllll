using Microsoft.AspNetCore.Mvc;
using PayChainX.Models;
using PayChainX.Services;

namespace PayChainX.Controllers;

public sealed class VposOverviewPage
{
    public GrafanaErrorDashboardResult Transactions { get; set; } = new();
    public GrafanaErrorDashboardResult Errors { get; set; } = new();
    public int Days { get; set; } = 30;
    public int Minutes { get; set; } = 30;
}

public class DashboardController:Controller
{
    private const string ConnectionCookie="paychainx_connection";
    private readonly GrafanaService _grafana;
    private readonly GrafanaDashboardDataService _grafanaData;
    private readonly ConnectionVault _vault;
    private readonly ElasticService _elastic;
    private readonly ExcelExportService _excel;
    private readonly IConfiguration _cfg;

    public DashboardController(ConnectionVault vault,ElasticService elastic,GrafanaService grafana,GrafanaDashboardDataService grafanaData,ExcelExportService excel,IConfiguration cfg)
    {
        _grafana=grafana;_grafanaData=grafanaData;_vault=vault;_elastic=elastic;_excel=excel;_cfg=cfg;
    }

    private static bool ValidUrl(string? url,IConfiguration cfg,string group)
    {
        if(string.IsNullOrWhiteSpace(url))return true;
        if(!Uri.TryCreate(url,UriKind.Absolute,out var uri)||uri.Scheme!="https"||!string.IsNullOrEmpty(uri.UserInfo))return false;
        var hosts=cfg.GetSection(group+":AllowedHosts").Get<string[]>()??Array.Empty<string>();
        return hosts.Length==0||hosts.Any(h=>string.Equals(h,uri.Host,StringComparison.OrdinalIgnoreCase));
    }

    private string? ConnectionId()
    {
        var id=HttpContext.Session.GetString("connection");
        if(!string.IsNullOrWhiteSpace(id))return id;
        if(Request.Cookies.TryGetValue(ConnectionCookie,out var cookie)&&!string.IsNullOrWhiteSpace(cookie))
        {
            HttpContext.Session.SetString("connection",cookie);
            return cookie;
        }
        return null;
    }

    private ConnectionInfo? CurrentConnection()=>_vault.Get(ConnectionId());

    [HttpGet]
    public IActionResult Login(bool force=false)
    {
        if(!force&&CurrentConnection()!=null)return RedirectToAction(nameof(VposOverview));
        return View(new LoginInput());
    }

    [HttpPost][ValidateAntiForgeryToken]
    public IActionResult Login(LoginInput input)
    {
        var hasGrafana=!string.IsNullOrWhiteSpace(input.GrafanaUrl);
        var hasElastic=!string.IsNullOrWhiteSpace(input.ElasticUrl);
        if(!hasGrafana&&!hasElastic)
        {
            ModelState.AddModelError("","En az Grafana dashboard URL'si girilmelidir.");
            return View(input);
        }
        if(!ValidUrl(input.GrafanaUrl,_cfg,"Grafana")||!ValidUrl(input.ElasticUrl,_cfg,"Elastic"))
        {
            ModelState.AddModelError("","Yalnızca HTTPS adresleri kullanılabilir. AllowedHosts doluysa hedef host listede bulunmalıdır.");
            return View(input);
        }
        if(hasGrafana&&(string.IsNullOrWhiteSpace(input.GrafanaUser)||string.IsNullOrWhiteSpace(input.GrafanaPassword)))
        {
            ModelState.AddModelError("","Grafana kullanıcı adı ve şifresi gereklidir.");
            return View(input);
        }
        if(hasElastic&&(string.IsNullOrWhiteSpace(input.ElasticUser)||string.IsNullOrWhiteSpace(input.ElasticPassword)))
        {
            ModelState.AddModelError("","Doğrudan Elastic bağlantısı kullanılacaksa Elastic kullanıcı adı ve şifresi gereklidir.");
            return View(input);
        }

        var previousId=ConnectionId();
        if(!string.IsNullOrWhiteSpace(previousId))_vault.Remove(previousId);
        var id=Guid.NewGuid().ToString("N");
        _vault.Put(id,new(input.ElasticUrl??"",input.ElasticUser??"",input.ElasticPassword??"",input.GrafanaUrl??"",input.GrafanaUser??"",input.GrafanaPassword??""));
        HttpContext.Session.SetString("connection",id);
        Response.Cookies.Append(ConnectionCookie,id,new CookieOptions
        {
            HttpOnly=true,
            IsEssential=true,
            Secure=Request.IsHttps,
            SameSite=SameSiteMode.Lax,
            Expires=DateTimeOffset.UtcNow.AddDays(30)
        });
        return hasGrafana?RedirectToAction(nameof(VposOverview)):RedirectToAction(nameof(Index));
    }

    [HttpPost][ValidateAntiForgeryToken]
    public IActionResult Logout()
    {
        _vault.Remove(ConnectionId());
        HttpContext.Session.Clear();
        Response.Cookies.Delete(ConnectionCookie);
        return RedirectToAction(nameof(Login));
    }

    [HttpGet("/VPOS")]
    public async Task<IActionResult> VposOverview(int minutes=30,CancellationToken ct=default)
    {
        var conn=CurrentConnection();if(conn==null)return RedirectToAction(nameof(Login));
        minutes=NormalizeMinutes(minutes);
        var txFilter=new GrafanaErrorFilter{Minutes=minutes,PanelGroup="Transactions"};
        var errorFilter=new GrafanaErrorFilter{Minutes=minutes,PanelGroup="Errors"};
        var txTask=_grafanaData.QueryAsync(conn,txFilter,ct);
        var errorTask=_grafanaData.QueryAsync(conn,errorFilter,ct);
        await Task.WhenAll(txTask,errorTask);
        return View(new VposOverviewPage{Transactions=await txTask,Errors=await errorTask,Minutes=minutes,Days=Math.Max(1,(int)Math.Ceiling(minutes/1440d))});
    }

    [HttpGet("/VPOS/Hatalar")]
    public async Task<IActionResult> VposErrors(string? customer,string? code,string? source,string? search,DateTime? from,DateTime? to,int minutes=30,int days=30,int page=1,CancellationToken ct=default)
    {
        var conn=CurrentConnection();if(conn==null)return RedirectToAction(nameof(Login));
        minutes=NormalizeMinutes(minutes);
        var filter=new GrafanaErrorFilter{Customer=customer,Code=code,Source=source,Search=search,From=from,To=to,Minutes=minutes,Days=Math.Clamp(days,1,365),Page=Math.Max(1,page),PanelGroup="Errors"};
        var data=await _grafanaData.QueryAsync(conn,filter,ct);
        ViewBag.GrafanaOpenUrl=_grafanaData.BuildGrafanaUrl(conn,filter);
        return View(data);
    }

    [HttpGet("/VPOS/Hatalar/Detay")]
    public async Task<IActionResult> VposErrorDetail(string? customer,string? code,string? source,string? search,DateTime? from,DateTime? to,int minutes=30,int days=30,CancellationToken ct=default)
    {
        var conn=CurrentConnection();if(conn==null)return RedirectToAction(nameof(Login));
        if(string.IsNullOrWhiteSpace(code)&&string.IsNullOrWhiteSpace(customer))return BadRequest("En az müşteri veya hata kodu gereklidir.");
        minutes=NormalizeMinutes(minutes);
        var filter=new GrafanaErrorFilter{Customer=customer,Code=code,Source=source,Search=search,From=from,To=to,Minutes=minutes,Days=Math.Clamp(days,1,365),PanelGroup="Errors",PageSize=500};
        var data=await _grafanaData.QueryAsync(conn,filter,ct);
        ViewBag.GrafanaOpenUrl=_grafanaData.BuildGrafanaUrl(conn,filter);
        ViewBag.CodeCatalog=CodeCatalog.Resolve(source,code);
        return View(data);
    }

    [HttpGet("/VPOS/Hatalar/Excel")]
    public async Task<IActionResult> VposErrorsExcel(string? customer,string? code,string? source,string? search,DateTime? from,DateTime? to,int minutes=30,int days=30,CancellationToken ct=default)
    {
        var conn=CurrentConnection();if(conn==null)return RedirectToAction(nameof(Login));
        minutes=NormalizeMinutes(minutes);
        var filter=new GrafanaErrorFilter{Customer=customer,Code=code,Source=source,Search=search,From=from,To=to,Minutes=minutes,Days=Math.Clamp(days,1,365),PanelGroup="Errors",PageSize=10000};
        var data=await _grafanaData.QueryAsync(conn,filter,ct);
        var bytes=_excel.BuildVposErrorWorkbook(data);
        return File(bytes,"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",$"VPOS_Hata_Raporu_{DateTime.Now:yyyyMMdd_HHmm}.xlsx");
    }

    [HttpGet("/VPOS/Kesintiler")]
    public async Task<IActionResult> VposCommissions(string? customer,string? source,string? search,DateTime? from,DateTime? to,int minutes=30,int days=30,CancellationToken ct=default)
    {
        var conn=CurrentConnection();if(conn==null)return RedirectToAction(nameof(Login));
        minutes=NormalizeMinutes(minutes);
        var filter=new GrafanaErrorFilter{Customer=customer,Source=source,Search=search,From=from,To=to,Minutes=minutes,Days=Math.Clamp(days,1,365),PanelGroup="Commissions"};
        var data=await _grafanaData.QueryAsync(conn,filter,ct);
        ViewBag.GrafanaOpenUrl=_grafanaData.BuildGrafanaUrl(conn,filter);
        return View(data);
    }

    [HttpGet]
    public async Task<IActionResult> Index([FromQuery]SearchInput filter,CancellationToken ct)
    {
        var connection=CurrentConnection();if(connection==null)return RedirectToAction(nameof(Login));
        if(string.IsNullOrWhiteSpace(connection.ElasticUrl))return View(new DashboardData{Filter=filter,GrafanaUrl=connection.GrafanaUrl,Error="Doğrudan Elastic bağlantısı yapılandırılmadı. VPOS ekranları Grafana dashboard üzerinden çalışır."});
        try{return View(await _elastic.Query(connection,filter,ct));}catch(Exception ex){return View(new DashboardData{Filter=filter,GrafanaUrl=connection.GrafanaUrl,Error=ex.Message});}
    }

    [HttpGet]
    public async Task<IActionResult> Detail(string customer,string code,int days=7,CancellationToken ct=default)
    {
        var conn=CurrentConnection();if(conn==null)return RedirectToAction(nameof(Login));
        if(string.IsNullOrWhiteSpace(customer)||string.IsNullOrWhiteSpace(code))return BadRequest("Müşteri ve kod gerekli.");
        var filter=new SearchInput{Customer=customer,Code=code,Days=Math.Clamp(days,1,30)};
        var match=CodeCatalog.Resolve("",code).FirstOrDefault();
        var explanation=match?.Meaning??"Kodun kesin açıklaması ilgili sağlayıcı sözlüğünden doğrulanmalı.";
        var recommendation=match?.Action??"Kaynak sistemi ve finansal sonucu incele.";
        try
        {
            var data=await _elastic.Query(conn,filter,ct);
            var cfg=_cfg.GetSection("CustomerMailConfigs").Get<List<CustomerMailConfig>>()?.FirstOrDefault(x=>string.Equals(x.Customer,customer,StringComparison.OrdinalIgnoreCase))??new CustomerMailConfig{Customer=customer};
            var draft=$"Konu: {customer} - {code} kodlu işlemler hakkında\n\nSayın {cfg.ContactName},\n\nSon {filter.Days} güne ait kayıtlarımızda {code} koduyla ilişkili {data.Total} log kaydı tespit edilmiştir. Bu sayı tekil ödeme adedini göstermeyebilir.\n\nÖn değerlendirme: {explanation}\n\nİlgili işlemlerin finansal sonuçları ve banka/ara sistem kayıtları kontrol edilmeden tahsilatın başarılı veya başarısız olduğu kesinleştirilemez. İnceleme sonucunda ayrıca bilgilendirme yapılacaktır.\n\nSaygılarımızla,\n{cfg.SupportSignature}";
            return View(new DetailPage{Data=data,Customer=customer,Code=code,Explanation=explanation,Recommendation=recommendation,Draft=draft,Config=cfg});
        }
        catch(Exception){return View(new DetailPage{Customer=customer,Code=code,Explanation=explanation,Recommendation=recommendation,Data=new DashboardData{Error="Elastic sorgusu tamamlanamadı. Bağlantı ve alan eşlemesini kontrol edin."}});}
    }

    [HttpGet]
    public async Task<IActionResult> Transaction(string id,int days=7,CancellationToken ct=default)
    {
        var conn=CurrentConnection();if(conn==null)return RedirectToAction(nameof(Login));
        if(string.IsNullOrWhiteSpace(id)||id.Length>200)return BadRequest("Geçersiz işlem ID");
        try{return View(new TransactionDetail{TransactionId=id,Data=await _elastic.Query(conn,new SearchInput{Transaction=id,Days=Math.Clamp(days,1,30)},ct)});}catch{return View(new TransactionDetail{TransactionId=id,Data=new DashboardData{Error="İşlem sorgusu başarısız. Elastic erişimini ve alan eşlemesini kontrol edin."}});}
    }

    [HttpGet]
    public async Task<IActionResult> Grafana(CancellationToken ct)
    {
        var conn=CurrentConnection();if(conn==null)return RedirectToAction(nameof(Login));
        try{ViewBag.Error=null;return View(await _grafana.Dashboards(conn,ct));}
        catch(Exception ex){ViewBag.Error=ex.Message;return View((IReadOnlyList<GrafanaDashboard>)Array.Empty<GrafanaDashboard>());}
    }

    [HttpGet]
    public async Task<IActionResult> ConnectionStatus(CancellationToken ct)
    {
        var conn=CurrentConnection();if(conn==null)return RedirectToAction(nameof(Login));
        var report=new Dictionary<string,string>();
        if(!string.IsNullOrWhiteSpace(conn.ElasticUrl))
        {
            try{await _elastic.Query(conn,new SearchInput{Days=1},ct);report["Elastic (doğrudan)"]="Bağlı / sorgu başarılı";}
            catch(Exception ex){report["Elastic (doğrudan)"]="Bağlantı veya sorgu hatası: "+ex.Message;}
        }
        else report["Elastic (doğrudan)"]="Kullanılmıyor; VPOS drill-down linkleri Grafana dashboard'dan alınır.";
        if(!string.IsNullOrWhiteSpace(conn.GrafanaUrl))
        {
            try
            {
                var dashboard=await _grafanaData.QueryAsync(conn,new GrafanaErrorFilter{Minutes=15,PanelGroup="Errors"},ct);
                report["Grafana Dashboard"]=string.IsNullOrWhiteSpace(dashboard.Error)?$"Bağlı / {dashboard.DashboardTitle}":"Bağlantı var, panel eşlemesi: "+dashboard.Error;
            }
            catch(Exception ex){report["Grafana Dashboard"]="Bağlantı veya yetki hatası: "+ex.Message;}
        }
        else report["Grafana Dashboard"]="Yapılandırılmadı";
        return View(report);
    }

    private static int NormalizeMinutes(int minutes)
    {
        return minutes switch
        {
            15 => 15,
            30 => 30,
            60 => 60,
            180 => 180,
            360 => 360,
            720 => 720,
            1440 => 1440,
            10080 => 10080,
            _ => 30
        };
    }

    [HttpGet]
    public IActionResult Codes(string? q)
    {
        ViewBag.Query=q;
        return View(CodeCatalog.Items.Values.Where(x=>string.IsNullOrWhiteSpace(q)||x.Code.Contains(q,StringComparison.OrdinalIgnoreCase)||x.Meaning.Contains(q,StringComparison.OrdinalIgnoreCase)||x.Layer.Contains(q,StringComparison.OrdinalIgnoreCase)).OrderBy(x=>x.Layer).ThenBy(x=>x.Code).ToList());
    }

    [HttpGet]
    public async Task<IActionResult> Export([FromQuery]SearchInput filter,CancellationToken ct)
    {
        var conn=CurrentConnection();if(conn==null)return RedirectToAction(nameof(Login));
        if(string.IsNullOrWhiteSpace(conn.ElasticUrl))return BadRequest("Doğrudan Elastic bağlantısı yapılandırılmadı. VPOS/Hatalar ekranındaki Excel butonunu kullanın.");
        var data=await _elastic.Query(conn,filter,ct);var sb=new System.Text.StringBuilder("Timestamp,Customer,Code,Status,Transaction,Source\r\n");
        static string Cell(string? v){v??="";if(v.Length>0&&"=+-@\t\r".Contains(v[0]))v="'"+v;return "\""+v.Replace("\"","\"\"")+"\"";}
        foreach(var r in data.Rows)sb.AppendLine(string.Join(",",new[]{r.Timestamp,r.Customer,r.Code,r.Status,r.Transaction,r.Source}.Select(Cell)));
        return File(System.Text.Encoding.UTF8.GetPreamble().Concat(System.Text.Encoding.UTF8.GetBytes(sb.ToString())).ToArray(),"text/csv","paychainx-log-kayitlari.csv");
    }

    public IActionResult Error()=>Content("Beklenmeyen hata oluştu.");
}
