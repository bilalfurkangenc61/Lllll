VPOS Grafana 15/30 Dakika Filtre Fix

- Çalışan Grafana bağlantı/login yöntemi DEĞİŞTİRİLMEDİ.
- Dashboard URL -> /d/{uid}/... okuma mantığı aynen devam eder.
- Basic Auth başarısızsa Grafana /login fallback aynen devam eder.
- Sadece sorgu zaman penceresi daraltıldı.
- Varsayılan: Son 30 dakika.
- Hızlı filtreler: 15 dk, 30 dk, 1 saat, 3 saat, 6 saat, 24 saat, ana sayfada ayrıca 7 gün.
- Verileri Güncelle seçili dakika aralığını yeniden sorgular.
- Hata ekranında manuel başlangıç/bitiş artık datetime-local ile dakika hassasiyetindedir.
- Excel, detay, firma/kod/kaynak drill-down seçili dakika aralığını korur.
- Model/entity/migration değişikliği YOK.

Not: Bu paket, mevcut GrafanaDashboardDataService tabanlı çalışan entegrasyonun sadece değişen dosyalarını içerir.
