using BtOperasyonTakip.ViewModels;

namespace BtOperasyonTakip.Services;

public interface IVposGrafanaService
{
    Task<VposGrafanaSnapshot> GetSnapshotAsync(
        VposMonitoringCredential credential,
        int lookbackMinutes,
        CancellationToken cancellationToken = default);

    Task<List<VposMonthlySummary>> GetMonthlySummaryAsync(VposMonitoringCredential credential, int year, CancellationToken cancellationToken = default);

    Task<VposGrafanaConnectionTest> TestConnectionAsync(
        VposMonitoringCredential credential,
        CancellationToken cancellationToken = default);
}
