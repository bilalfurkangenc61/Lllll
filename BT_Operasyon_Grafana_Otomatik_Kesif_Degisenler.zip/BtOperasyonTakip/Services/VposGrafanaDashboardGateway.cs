using System.Globalization;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using BtOperasyonTakip.Dtos;
using Microsoft.Extensions.Options;

namespace BtOperasyonTakip.Services;

public sealed class VposGrafanaDashboardGateway : IVposGrafanaDashboardGateway
{
    private readonly HttpClient _httpClient;
    private readonly VposGrafanaDashboardOptions _options;
    private readonly ILogger<VposGrafanaDashboardGateway> _logger;

    public VposGrafanaDashboardGateway(
        HttpClient httpClient,
        IOptions<VposGrafanaDashboardOptions> options,
        ILogger<VposGrafanaDashboardGateway> logger)
    {
        _httpClient = httpClient;
        _options = options.Value;
        _logger = logger;
    }

    public async Task<VposGrafanaConnectionInfo> TestAsync(
        VposMonitoringCredential credential,
        CancellationToken cancellationToken = default)
    {
        try
        {
            var address = await ResolveDashboardAddressAsync(credential, cancellationToken);
            var auth = await AuthenticateAsync(address.BaseUrl, credential, cancellationToken);
            using var document = await GetDashboardAsync(address, auth, cancellationToken);
            var dashboard = GetDashboardNode(document.RootElement);
            var title = ReadString(dashboard, "title") ?? address.Uid;
            var panels = FlattenPanels(dashboard).Where(HasTargets).ToList();

            return new VposGrafanaConnectionInfo
            {
                Success = true,
                Message = $"Grafana dashboard bağlantısı başarılı. {panels.Count} sorgulanabilir panel bulundu.",
                DashboardTitle = title,
                PanelCount = panels.Count
            };
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "VPOS Grafana dashboard bağlantı testi başarısız.");
            return new VposGrafanaConnectionInfo
            {
                Success = false,
                Message = Friendly(ex)
            };
        }
    }

    public async Task<VposMonitoringResult> QueryAsync(
        VposMonitoringCredential credential,
        VposMonitoringFilter filter,
        string purpose,
        CancellationToken cancellationToken = default)
    {
        var result = new VposMonitoringResult { RetrievedAt = DateTime.Now };

        try
        {
            var normalizedFilter = filter.Normalized();
            var address = await ResolveDashboardAddressAsync(credential, cancellationToken);
            var auth = await AuthenticateAsync(address.BaseUrl, credential, cancellationToken);
            using var dashboardDocument = await GetDashboardAsync(address, auth, cancellationToken);
            var dashboard = GetDashboardNode(dashboardDocument.RootElement);

            result.DashboardTitle = ReadString(dashboard, "title") ?? address.Uid;
            result.DashboardUrl = credential.DashboardUrl;

            var allPanels = FlattenPanels(dashboard).Where(HasTargets).ToList();
            var selectedPanels = SelectPanels(allPanels, purpose).Take(Math.Max(1, _options.MaxPanelsPerRequest)).ToList();
            result.PanelCount = selectedPanels.Count;

            if (selectedPanels.Count == 0)
                throw new InvalidOperationException("Dashboard içinde sorgulanabilir panel bulunamadı.");

            var variableMap = BuildVariableMap(dashboard, normalizedFilter);
            var rows = new List<VposMonitoringRow>();

            foreach (var panel in selectedPanels)
            {
                cancellationToken.ThrowIfCancellationRequested();
                try
                {
                    var panelRows = await QueryPanelAsync(
                        address,
                        auth,
                        dashboard,
                        panel,
                        variableMap,
                        normalizedFilter,
                        credential.ElasticUrl,
                        cancellationToken);
                    rows.AddRange(panelRows);
                    if (rows.Count >= _options.MaxRows)
                        break;
                }
                catch (Exception ex)
                {
                    var panelTitle = ReadString(panel, "title") ?? "Panel";
                    _logger.LogWarning(ex, "Grafana panel sorgusu başarısız: {PanelTitle}", panelTitle);
                }
            }

            rows = rows.Take(Math.Max(100, _options.MaxRows)).ToList();
            rows = ApplyClientFilters(rows, normalizedFilter);

            result.Rows = rows
                .OrderByDescending(x => x.Timestamp ?? DateTime.MinValue)
                .ToList();

            result.Companies = Group(rows, x => x.Customer)
                .Where(x => x.Key != "-")
                .Take(1000)
                .ToList();
            result.Errors = Group(rows, x => x.NormalizedCode)
                .Where(x => x.Key != "-")
                .Take(1000)
                .ToList();
            result.Sources = Group(rows, x => x.Source).Take(100).ToList();
            result.Days = rows
                .Where(x => x.Timestamp.HasValue)
                .GroupBy(x => x.Timestamp!.Value.Date)
                .OrderByDescending(x => x.Key)
                .Select(x => new VposCountItem
                {
                    Key = x.Key.ToString("dd.MM.yyyy", CultureInfo.GetCultureInfo("tr-TR")),
                    Count = x.Sum(y => Math.Max(1, y.Count))
                })
                .ToList();

            result.Success = true;
            result.Message = rows.Count == 0
                ? "Dashboard sorguları çalıştı ancak seçilen filtrelerde kayıt bulunamadı."
                : $"Grafana dashboard üzerinden {rows.Count:N0} satır alındı.";
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "VPOS Grafana dashboard verisi alınamadı.");
            result.Success = false;
            result.Message = Friendly(ex);
        }

        return result;
    }

    private async Task<List<VposMonitoringRow>> QueryPanelAsync(
        DashboardAddress address,
        GrafanaAuth auth,
        JsonElement dashboard,
        JsonElement panel,
        IReadOnlyDictionary<string, string> variableMap,
        VposMonitoringFilter filter,
        string? elasticFallbackUrl,
        CancellationToken cancellationToken)
    {
        if (!panel.TryGetProperty("targets", out var targets) || targets.ValueKind != JsonValueKind.Array)
            return new List<VposMonitoringRow>();

        var panelId = ReadInt(panel, "id");
        var panelTitle = ReadString(panel, "title") ?? $"Panel {panelId}";
        var panelDatasource = panel.TryGetProperty("datasource", out var ds) ? ds : default;
        var queryNodes = new List<JsonObject>();

        foreach (var target in targets.EnumerateArray())
        {
            if (target.ValueKind != JsonValueKind.Object) continue;
            if (target.TryGetProperty("hide", out var hidden) && hidden.ValueKind == JsonValueKind.True) continue;

            var node = JsonNode.Parse(target.GetRawText()) as JsonObject;
            if (node == null) continue;

            ReplaceVariables(node, variableMap);
            EnsureDatasource(node, panelDatasource, variableMap);

            if (node["refId"] == null)
                node["refId"] = ((char)('A' + Math.Min(queryNodes.Count, 25))).ToString();
            if (node["maxDataPoints"] == null)
                node["maxDataPoints"] = Math.Max(1000, _options.MaxRows);
            if (node["intervalMs"] == null)
                node["intervalMs"] = 1000;

            if (HasDatasourceUid(node))
                queryNodes.Add(node);
        }

        if (queryNodes.Count == 0)
            return new List<VposMonitoringRow>();

        var payload = new JsonObject
        {
            ["queries"] = new JsonArray(queryNodes.Select(x => (JsonNode)x).ToArray()),
            ["from"] = new DateTimeOffset(filter.EffectiveFrom).ToUnixTimeMilliseconds().ToString(CultureInfo.InvariantCulture),
            ["to"] = new DateTimeOffset(filter.EffectiveTo).ToUnixTimeMilliseconds().ToString(CultureInfo.InvariantCulture)
        };

        using var request = NewRequest(HttpMethod.Post, $"{address.BaseUrl}/api/ds/query", auth);
        request.Content = new StringContent(payload.ToJsonString(), Encoding.UTF8, "application/json");
        using var response = await _httpClient.SendAsync(request, cancellationToken);
        var json = await response.Content.ReadAsStringAsync(cancellationToken);

        if (!response.IsSuccessStatusCode)
            throw new InvalidOperationException($"Grafana panel sorgusu HTTP {(int)response.StatusCode}: {TrimMessage(json)}");

        using var responseDoc = JsonDocument.Parse(json);
        var links = GetPanelLinks(panel);
        var grafanaPanelUrl = BuildGrafanaPanelUrl(credentialDashboardUrl: address.OriginalDashboardUrl, panelId, filter, dashboard);
        return ParseFrames(responseDoc.RootElement, panelTitle, panelId, links, grafanaPanelUrl, elasticFallbackUrl);
    }

    private List<VposMonitoringRow> ParseFrames(
        JsonElement root,
        string panelTitle,
        int? panelId,
        IReadOnlyList<string> links,
        string grafanaPanelUrl,
        string? elasticFallbackUrl)
    {
        var rows = new List<VposMonitoringRow>();
        if (!root.TryGetProperty("results", out var results) || results.ValueKind != JsonValueKind.Object)
            return rows;

        foreach (var resultProperty in results.EnumerateObject())
        {
            var result = resultProperty.Value;
            if (!result.TryGetProperty("frames", out var frames) || frames.ValueKind != JsonValueKind.Array)
                continue;

            foreach (var frame in frames.EnumerateArray())
            {
                if (!frame.TryGetProperty("schema", out var schema) || !schema.TryGetProperty("fields", out var fields) || fields.ValueKind != JsonValueKind.Array)
                    continue;
                if (!frame.TryGetProperty("data", out var data) || !data.TryGetProperty("values", out var values) || values.ValueKind != JsonValueKind.Array)
                    continue;

                var fieldNames = fields.EnumerateArray()
                    .Select((x, i) => ReadString(x, "name") ?? $"field{i}")
                    .ToList();
                var valueArrays = values.EnumerateArray().ToList();
                var rowCount = valueArrays.Count == 0 ? 0 : valueArrays.Max(x => x.ValueKind == JsonValueKind.Array ? x.GetArrayLength() : 0);

                for (var rowIndex = 0; rowIndex < rowCount; rowIndex++)
                {
                    var map = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                    for (var fieldIndex = 0; fieldIndex < fieldNames.Count && fieldIndex < valueArrays.Count; fieldIndex++)
                    {
                        var array = valueArrays[fieldIndex];
                        if (array.ValueKind != JsonValueKind.Array || rowIndex >= array.GetArrayLength()) continue;
                        map[fieldNames[fieldIndex]] = ElementToString(array[rowIndex]);
                    }

                    if (map.Count == 0) continue;
                    var row = MapRow(map, panelTitle, panelId, links, grafanaPanelUrl, elasticFallbackUrl);
                    rows.Add(row);
                }
            }
        }
        return rows;
    }

    private VposMonitoringRow MapRow(
        Dictionary<string, string> map,
        string panelTitle,
        int? panelId,
        IReadOnlyList<string> links,
        string grafanaPanelUrl,
        string? elasticFallbackUrl)
    {
        var customer = FindField(map, _options.CustomerFieldKeywords) ?? "-";
        var sourceRaw = FindField(map, _options.SourceFieldKeywords) ?? InferSource(panelTitle);
        var codeRaw = FindField(map, _options.ErrorCodeFieldKeywords) ?? InferCode(map, panelTitle) ?? "-";
        var message = FindField(map, _options.MessageFieldKeywords) ?? "-";
        var def = VposErrorCatalog.Resolve(sourceRaw, codeRaw, message);
        var timestamp = ParseDate(FindField(map, _options.TimestampFieldKeywords));
        var transaction = FindField(map, _options.TransactionFieldKeywords) ?? "-";
        var amount = FindField(map, _options.AmountFieldKeywords) ?? "-";
        var status = FindField(map, _options.StatusFieldKeywords) ?? "-";
        var count = ParseCount(FindField(map, _options.CountFieldKeywords));
        var external = ResolveExternalLink(links, map, def, customer, transaction, timestamp) ?? NormalizeFallbackUrl(elasticFallbackUrl);

        return new VposMonitoringRow
        {
            Timestamp = timestamp,
            Customer = customer,
            Source = def.Source,
            RawCode = def.RawCode,
            NormalizedCode = def.NormalizedCode,
            Description = def.Description,
            GeneralDescription = def.GeneralDescription,
            Context = def.Context,
            TransactionId = transaction,
            Amount = amount,
            Status = status,
            Message = message,
            Count = count,
            PanelTitle = panelTitle,
            PanelId = panelId,
            GrafanaUrl = grafanaPanelUrl,
            ExternalLogUrl = external,
            Fields = map
        };
    }

    private static List<VposMonitoringRow> ApplyClientFilters(
        IEnumerable<VposMonitoringRow> source,
        VposMonitoringFilter filter)
    {
        var query = source;
        if (!string.IsNullOrWhiteSpace(filter.Customer))
            query = query.Where(x => Contains(x.Customer, filter.Customer));
        if (!string.IsNullOrWhiteSpace(filter.Source))
            query = query.Where(x => Contains(x.Source, filter.Source));
        if (!string.IsNullOrWhiteSpace(filter.Code))
        {
            var normalized = VposErrorCatalog.NormalizeIso(filter.Code);
            query = query.Where(x =>
                string.Equals(x.NormalizedCode, normalized, StringComparison.OrdinalIgnoreCase) ||
                Contains(x.RawCode, filter.Code));
        }
        if (!string.IsNullOrWhiteSpace(filter.Q))
        {
            var q = filter.Q;
            query = query.Where(x =>
                x.Fields.Values.Any(v => Contains(v, q)) ||
                Contains(x.Description, q) || Contains(x.GeneralDescription, q));
        }
        query = query.Where(x => !x.Timestamp.HasValue || (x.Timestamp.Value >= filter.EffectiveFrom && x.Timestamp.Value <= filter.EffectiveTo));
        return query.ToList();
    }

    private static IEnumerable<VposCountItem> Group(IEnumerable<VposMonitoringRow> rows, Func<VposMonitoringRow, string> selector) =>
        rows.GroupBy(selector, StringComparer.OrdinalIgnoreCase)
            .Select(x => new VposCountItem { Key = x.Key, Count = x.Sum(y => Math.Max(1, y.Count)) })
            .OrderByDescending(x => x.Count)
            .ThenBy(x => x.Key);

    private List<JsonElement> SelectPanels(IReadOnlyList<JsonElement> panels, string purpose)
    {
        var keywords = purpose.ToLowerInvariant() switch
        {
            "errors" => _options.ErrorPanelKeywords,
            "outages" => _options.OutagePanelKeywords,
            "transactions" => _options.TransactionPanelKeywords,
            _ => _options.TransactionPanelKeywords.Concat(_options.ErrorPanelKeywords).Distinct(StringComparer.OrdinalIgnoreCase).ToArray()
        };

        var matched = panels.Where(p =>
        {
            var title = ReadString(p, "title") ?? string.Empty;
            return keywords.Any(k => title.Contains(k, StringComparison.OrdinalIgnoreCase));
        }).ToList();

        if (matched.Count > 0) return matched;
        return panels.Where(IsLikelyDataPanel).ToList();
    }

    private static bool IsLikelyDataPanel(JsonElement panel)
    {
        var type = ReadString(panel, "type") ?? string.Empty;
        return !type.Equals("text", StringComparison.OrdinalIgnoreCase) &&
               !type.Equals("row", StringComparison.OrdinalIgnoreCase) &&
               !type.Equals("dashlist", StringComparison.OrdinalIgnoreCase);
    }

    private static bool HasTargets(JsonElement panel) =>
        panel.TryGetProperty("targets", out var targets) &&
        targets.ValueKind == JsonValueKind.Array &&
        targets.GetArrayLength() > 0;

    private static List<JsonElement> FlattenPanels(JsonElement dashboard)
    {
        var result = new List<JsonElement>();
        if (!dashboard.TryGetProperty("panels", out var panels) || panels.ValueKind != JsonValueKind.Array)
            return result;
        WalkPanels(panels, result);
        return result;
    }

    private static void WalkPanels(JsonElement panels, ICollection<JsonElement> result)
    {
        foreach (var panel in panels.EnumerateArray())
        {
            result.Add(panel.Clone());
            if (panel.TryGetProperty("panels", out var nested) && nested.ValueKind == JsonValueKind.Array)
                WalkPanels(nested, result);
        }
    }

    private IReadOnlyDictionary<string, string> BuildVariableMap(JsonElement dashboard, VposMonitoringFilter filter)
    {
        var values = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        if (!dashboard.TryGetProperty("templating", out var templating) ||
            !templating.TryGetProperty("list", out var list) ||
            list.ValueKind != JsonValueKind.Array)
            return values;

        foreach (var variable in list.EnumerateArray())
        {
            var name = ReadString(variable, "name");
            if (string.IsNullOrWhiteSpace(name)) continue;
            var label = ReadString(variable, "label") ?? name;
            var descriptor = name + " " + label;

            string? selected = null;
            if (MatchesAny(descriptor, _options.CustomerFieldKeywords)) selected = filter.Customer ?? ".*";
            else if (MatchesAny(descriptor, _options.ErrorCodeFieldKeywords)) selected = filter.Code ?? ".*";
            else if (MatchesAny(descriptor, _options.SourceFieldKeywords)) selected = filter.Source ?? ".*";

            if (selected != null)
                values[name] = selected;
            else if (variable.TryGetProperty("current", out var current))
            {
                var currentValue = CurrentVariableValue(current);
                if (!string.IsNullOrWhiteSpace(currentValue)) values[name] = currentValue;
            }
        }
        return values;
    }

    private static string? CurrentVariableValue(JsonElement current)
    {
        if (!current.TryGetProperty("value", out var value)) return null;
        return value.ValueKind switch
        {
            JsonValueKind.String => value.GetString(),
            JsonValueKind.Array => string.Join(",", value.EnumerateArray().Select(ElementToString)),
            _ => ElementToString(value)
        };
    }

    private static void ReplaceVariables(JsonNode node, IReadOnlyDictionary<string, string> variables)
    {
        if (node is JsonObject obj)
        {
            foreach (var key in obj.Select(x => x.Key).ToList())
            {
                var child = obj[key];
                if (child is JsonValue value && value.TryGetValue<string>(out var text))
                    obj[key] = ReplaceVariableText(text, variables);
                else if (child != null)
                    ReplaceVariables(child, variables);
            }
        }
        else if (node is JsonArray arr)
        {
            for (var i = 0; i < arr.Count; i++)
            {
                var child = arr[i];
                if (child is JsonValue value && value.TryGetValue<string>(out var text))
                    arr[i] = ReplaceVariableText(text, variables);
                else if (child != null)
                    ReplaceVariables(child, variables);
            }
        }
    }

    private static string ReplaceVariableText(string text, IReadOnlyDictionary<string, string> variables)
    {
        var result = text;
        foreach (var pair in variables)
        {
            result = result.Replace("$" + pair.Key, pair.Value, StringComparison.OrdinalIgnoreCase);
            result = Regex.Replace(result, @"\$\{" + Regex.Escape(pair.Key) + @"(?::[^}]*)?\}", _ => pair.Value, RegexOptions.IgnoreCase);
            result = Regex.Replace(result, @"\[\[" + Regex.Escape(pair.Key) + @"(?::[^]]*)?\]\]", _ => pair.Value, RegexOptions.IgnoreCase);
        }
        return result;
    }

    private static void EnsureDatasource(JsonObject target, JsonElement panelDatasource, IReadOnlyDictionary<string, string> variables)
    {
        if (target["datasource"] == null && panelDatasource.ValueKind != JsonValueKind.Undefined && panelDatasource.ValueKind != JsonValueKind.Null)
        {
            var node = JsonNode.Parse(panelDatasource.GetRawText());
            if (node != null)
            {
                ReplaceVariables(node, variables);
                target["datasource"] = node;
            }
        }

        if (target["datasource"] is JsonValue value && value.TryGetValue<string>(out var uid))
            target["datasource"] = new JsonObject { ["uid"] = uid };
    }

    private static bool HasDatasourceUid(JsonObject target)
    {
        if (target["datasource"] is not JsonObject ds) return false;
        return ds["uid"] is JsonValue uid && uid.TryGetValue<string>(out var value) && !string.IsNullOrWhiteSpace(value);
    }

    private async Task<GrafanaAuth> AuthenticateAsync(string baseUrl, VposMonitoringCredential credential, CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(credential.Username) || string.IsNullOrWhiteSpace(credential.Password))
            throw new InvalidOperationException("Grafana kullanıcı adı ve şifresi gerekli.");

        var basic = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{credential.Username}:{credential.Password}"));
        using (var request = new HttpRequestMessage(HttpMethod.Get, $"{baseUrl}/api/user"))
        {
            request.Headers.Authorization = new AuthenticationHeaderValue("Basic", basic);
            using var response = await _httpClient.SendAsync(request, cancellationToken);
            if (response.IsSuccessStatusCode)
                return new GrafanaAuth { BasicToken = basic };
        }

        using var loginRequest = new HttpRequestMessage(HttpMethod.Post, $"{baseUrl}/login");
        loginRequest.Content = new StringContent(JsonSerializer.Serialize(new
        {
            user = credential.Username,
            password = credential.Password
        }), Encoding.UTF8, "application/json");

        using var loginResponse = await _httpClient.SendAsync(loginRequest, cancellationToken);
        var body = await loginResponse.Content.ReadAsStringAsync(cancellationToken);
        if (!loginResponse.IsSuccessStatusCode)
            throw new InvalidOperationException($"Grafana giriş başarısız. HTTP {(int)loginResponse.StatusCode}: {TrimMessage(body)}");

        if (!loginResponse.Headers.TryGetValues("Set-Cookie", out var cookies))
            throw new InvalidOperationException("Grafana giriş oturumu oluşturulamadı. Kurulum SSO/LDAP kullanıyor olabilir.");

        var cookie = string.Join("; ", cookies.Select(x => x.Split(';', 2)[0].Trim()).Where(x => x.Length > 0));
        if (string.IsNullOrWhiteSpace(cookie))
            throw new InvalidOperationException("Grafana oturum cookie'si alınamadı.");

        using var verify = NewRequest(HttpMethod.Get, $"{baseUrl}/api/user", new GrafanaAuth { CookieHeader = cookie });
        using var verifyResponse = await _httpClient.SendAsync(verify, cancellationToken);
        if (!verifyResponse.IsSuccessStatusCode)
            throw new InvalidOperationException("Grafana oturumu açıldı ancak API erişimine izin verilmedi.");

        return new GrafanaAuth { CookieHeader = cookie };
    }

    private async Task<JsonDocument> GetDashboardAsync(DashboardAddress address, GrafanaAuth auth, CancellationToken cancellationToken)
    {
        using var request = NewRequest(HttpMethod.Get, $"{address.BaseUrl}/api/dashboards/uid/{Uri.EscapeDataString(address.Uid)}", auth);
        using var response = await _httpClient.SendAsync(request, cancellationToken);
        var body = await response.Content.ReadAsStringAsync(cancellationToken);
        if (!response.IsSuccessStatusCode)
            throw new InvalidOperationException($"Grafana dashboard okunamadı. HTTP {(int)response.StatusCode}: {TrimMessage(body)}");
        return JsonDocument.Parse(body);
    }

    private static JsonElement GetDashboardNode(JsonElement root)
    {
        if (root.TryGetProperty("dashboard", out var dashboard)) return dashboard;
        if (root.TryGetProperty("spec", out var spec)) return spec;
        throw new InvalidOperationException("Grafana dashboard JSON formatı tanınamadı.");
    }

    private static HttpRequestMessage NewRequest(HttpMethod method, string url, GrafanaAuth auth)
    {
        var request = new HttpRequestMessage(method, url);
        request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        if (!string.IsNullOrWhiteSpace(auth.BasicToken))
            request.Headers.Authorization = new AuthenticationHeaderValue("Basic", auth.BasicToken);
        if (!string.IsNullOrWhiteSpace(auth.CookieHeader))
            request.Headers.TryAddWithoutValidation("Cookie", auth.CookieHeader);
        return request;
    }


    private async Task<DashboardAddress> ResolveDashboardAddressAsync(VposMonitoringCredential credential, CancellationToken cancellationToken)
    {
        var raw = string.IsNullOrWhiteSpace(credential.DashboardUrl) ? credential.GrafanaUrl : credential.DashboardUrl;
        if (string.IsNullOrWhiteSpace(raw)) throw new InvalidOperationException("Grafana sunucu adresi kayıtlı değil.");
        if (!Uri.TryCreate(raw, UriKind.Absolute, out var uri)) throw new InvalidOperationException("Grafana sunucu adresi geçersiz.");
        var segments = uri.AbsolutePath.Split('/', StringSplitOptions.RemoveEmptyEntries);
        if (segments.Any(x => x.Equals("d", StringComparison.OrdinalIgnoreCase) || x.Equals("d-solo", StringComparison.OrdinalIgnoreCase)))
            return ParseDashboardAddress(credential);
        var baseUrl = raw.TrimEnd('/');
        if (uri.AbsolutePath != "/" && uri.AbsolutePath.Length > 1) baseUrl = $"{uri.Scheme}://{uri.Authority}{uri.AbsolutePath.TrimEnd('/')}";
        if (_options.AllowedHosts.Length > 0 && !_options.AllowedHosts.Any(x => string.Equals(x, uri.Host, StringComparison.OrdinalIgnoreCase)))
            throw new InvalidOperationException("Grafana host adresi izinli listede değil.");
        var auth = await AuthenticateAsync(baseUrl, credential, cancellationToken);
        using var request = NewRequest(HttpMethod.Get, $"{baseUrl}/api/search?type=dash-db&limit=5000", auth);
        using var response = await _httpClient.SendAsync(request, cancellationToken);
        if (!response.IsSuccessStatusCode) throw new InvalidOperationException($"Grafana dashboard keşfi HTTP {(int)response.StatusCode} ile başarısız.");
        using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync(cancellationToken));
        if (doc.RootElement.ValueKind != JsonValueKind.Array) throw new InvalidOperationException("Grafana dashboard listesi beklenen biçimde değil.");
        var matches = doc.RootElement.EnumerateArray().Select(x => new {
            Uid = ReadString(x, "uid"), Title = ReadString(x, "title") ?? "", Url = ReadString(x, "url") ?? ""
        }).Where(x => !string.IsNullOrWhiteSpace(x.Uid) &&
            (x.Title.Contains("VPOS", StringComparison.OrdinalIgnoreCase) || x.Title.Contains("Business / Infra", StringComparison.OrdinalIgnoreCase)))
          .OrderByDescending(x => x.Title.Contains("Business / Infra", StringComparison.OrdinalIgnoreCase)).ToList();
        if (matches.Count == 0) throw new InvalidOperationException("Grafana üzerinde erişilebilir VPOS dashboard bulunamadı.");
        if (matches.Count > 1 && !matches[0].Title.Contains("Business / Infra", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("Birden fazla VPOS dashboard bulundu; yanlış dashboard seçilmedi.");
        var chosen = matches[0];
        var dashboardUrl = baseUrl + (chosen.Url.StartsWith('/') ? chosen.Url : "/d/" + chosen.Uid);
        return new DashboardAddress(baseUrl, chosen.Uid!, dashboardUrl);
    }

    private DashboardAddress ParseDashboardAddress(VposMonitoringCredential credential)
    {
        var dashboardUrl = string.IsNullOrWhiteSpace(credential.DashboardUrl) ? credential.GrafanaUrl : credential.DashboardUrl;
        if (string.IsNullOrWhiteSpace(dashboardUrl))
            throw new InvalidOperationException("Grafana dashboard URL'si girilmedi.");
        if (!Uri.TryCreate(dashboardUrl, UriKind.Absolute, out var uri) || (uri.Scheme != "https" && uri.Scheme != "http"))
            throw new InvalidOperationException("Grafana dashboard URL'si geçerli değil.");
        if (!string.IsNullOrWhiteSpace(uri.UserInfo))
            throw new InvalidOperationException("Grafana URL içinde kullanıcı adı/şifre bulunmamalı.");
        if (_options.AllowedHosts.Length > 0 && !_options.AllowedHosts.Any(x => string.Equals(x, uri.Host, StringComparison.OrdinalIgnoreCase)))
            throw new InvalidOperationException("Grafana host adresi VposGrafanaDashboard:AllowedHosts listesinde değil.");

        var segments = uri.AbsolutePath.Split('/', StringSplitOptions.RemoveEmptyEntries);
        var markerIndex = Array.FindIndex(segments, x => x.Equals("d", StringComparison.OrdinalIgnoreCase) || x.Equals("d-solo", StringComparison.OrdinalIgnoreCase));
        if (markerIndex < 0 || markerIndex + 1 >= segments.Length)
            throw new InvalidOperationException("Dashboard URL içinde /d/{uid}/... yapısı bulunamadı.");

        var uid = segments[markerIndex + 1];
        var prefix = markerIndex == 0 ? string.Empty : "/" + string.Join('/', segments.Take(markerIndex));
        var baseUrl = $"{uri.Scheme}://{uri.Authority}{prefix}".TrimEnd('/');
        return new DashboardAddress(baseUrl, uid, dashboardUrl);
    }

    private static string BuildGrafanaPanelUrl(string credentialDashboardUrl, int? panelId, VposMonitoringFilter filter, JsonElement dashboard)
    {
        if (!Uri.TryCreate(credentialDashboardUrl, UriKind.Absolute, out var uri)) return credentialDashboardUrl;
        var query = ParseQuery(uri.Query);
        query["from"] = new DateTimeOffset(filter.EffectiveFrom).ToUnixTimeMilliseconds().ToString(CultureInfo.InvariantCulture);
        query["to"] = new DateTimeOffset(filter.EffectiveTo).ToUnixTimeMilliseconds().ToString(CultureInfo.InvariantCulture);
        if (panelId.HasValue) query["viewPanel"] = panelId.Value.ToString(CultureInfo.InvariantCulture);

        if (dashboard.TryGetProperty("templating", out var templating) && templating.TryGetProperty("list", out var list) && list.ValueKind == JsonValueKind.Array)
        {
            foreach (var variable in list.EnumerateArray())
            {
                var name = ReadString(variable, "name");
                var label = ReadString(variable, "label") ?? name;
                if (string.IsNullOrWhiteSpace(name)) continue;
                var descriptor = name + " " + label;
                if (!string.IsNullOrWhiteSpace(filter.Customer) && MatchesAny(descriptor, ["customer", "merchant", "firma", "musteri", "müşteri", "uye"])) query[$"var-{name}"] = filter.Customer;
                else if (!string.IsNullOrWhiteSpace(filter.Source) && MatchesAny(descriptor, ["source", "provider", "processor", "kaynak", "bank"])) query[$"var-{name}"] = filter.Source;
                else if (!string.IsNullOrWhiteSpace(filter.Code) && MatchesAny(descriptor, ["error", "hata", "code", "response", "iso"])) query[$"var-{name}"] = filter.Code;
            }
        }

        var builder = new UriBuilder(uri) { Query = string.Join('&', query.Select(x => $"{Uri.EscapeDataString(x.Key)}={Uri.EscapeDataString(x.Value)}")) };
        return builder.Uri.ToString();
    }

    private static Dictionary<string, string> ParseQuery(string query)
    {
        var result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var part in query.TrimStart('?').Split('&', StringSplitOptions.RemoveEmptyEntries))
        {
            var pieces = part.Split('=', 2);
            result[Uri.UnescapeDataString(pieces[0])] = pieces.Length > 1 ? Uri.UnescapeDataString(pieces[1]) : string.Empty;
        }
        return result;
    }

    private static IReadOnlyList<string> GetPanelLinks(JsonElement panel)
    {
        var result = new List<string>();
        CollectUrls(panel, result);
        return result
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
    }

    private static void CollectUrls(JsonElement element, ICollection<string> result)
    {
        if (element.ValueKind == JsonValueKind.Object)
        {
            foreach (var property in element.EnumerateObject())
            {
                if (property.Name.Equals("url", StringComparison.OrdinalIgnoreCase) && property.Value.ValueKind == JsonValueKind.String)
                {
                    var value = property.Value.GetString();
                    if (!string.IsNullOrWhiteSpace(value)) result.Add(value);
                }
                else if (property.Value.ValueKind is JsonValueKind.Object or JsonValueKind.Array)
                {
                    CollectUrls(property.Value, result);
                }
            }
        }
        else if (element.ValueKind == JsonValueKind.Array)
        {
            foreach (var item in element.EnumerateArray()) CollectUrls(item, result);
        }
    }

    private static string? ResolveExternalLink(
        IReadOnlyList<string> links,
        IReadOnlyDictionary<string, string> fields,
        VposErrorDefinition error,
        string customer,
        string transaction,
        DateTime? timestamp)
    {
        var template = links.FirstOrDefault(x =>
            x.Contains("elastic", StringComparison.OrdinalIgnoreCase) ||
            x.Contains("kibana", StringComparison.OrdinalIgnoreCase) ||
            x.Contains("discover", StringComparison.OrdinalIgnoreCase) ||
            x.Contains("logs", StringComparison.OrdinalIgnoreCase));
        if (string.IsNullOrWhiteSpace(template)) return null;

        var result = template;
        result = result.Replace("${__value.text}", Uri.EscapeDataString(error.RawCode), StringComparison.OrdinalIgnoreCase)
            .Replace("${__value.raw}", Uri.EscapeDataString(error.RawCode), StringComparison.OrdinalIgnoreCase)
            .Replace("$customer", Uri.EscapeDataString(customer), StringComparison.OrdinalIgnoreCase)
            .Replace("$transaction", Uri.EscapeDataString(transaction), StringComparison.OrdinalIgnoreCase);

        foreach (var pair in fields)
        {
            var escaped = Uri.EscapeDataString(pair.Value ?? string.Empty);
            var pattern = "\\$\\{__data\\.fields\\[?[\\\"']?" + Regex.Escape(pair.Key) + "[\\\"']?\\]?\\}";
            result = Regex.Replace(result, pattern, _ => escaped, RegexOptions.IgnoreCase);
        }

        if (timestamp.HasValue)
            result = result.Replace("${__from}", new DateTimeOffset(timestamp.Value.AddMinutes(-5)).ToUnixTimeMilliseconds().ToString(CultureInfo.InvariantCulture), StringComparison.OrdinalIgnoreCase)
                .Replace("${__to}", new DateTimeOffset(timestamp.Value.AddMinutes(5)).ToUnixTimeMilliseconds().ToString(CultureInfo.InvariantCulture), StringComparison.OrdinalIgnoreCase);
        return result;
    }

    private static string? NormalizeFallbackUrl(string? url)
    {
        if (string.IsNullOrWhiteSpace(url)) return null;
        return Uri.TryCreate(url, UriKind.Absolute, out var uri) && (uri.Scheme == "https" || uri.Scheme == "http") && string.IsNullOrWhiteSpace(uri.UserInfo)
            ? uri.ToString()
            : null;
    }

    private static string? FindField(IReadOnlyDictionary<string, string> map, IReadOnlyList<string> keywords)
    {
        foreach (var key in keywords)
        {
            var exact = map.FirstOrDefault(x => NormalizeName(x.Key) == NormalizeName(key));
            if (!string.IsNullOrWhiteSpace(exact.Key) && !string.IsNullOrWhiteSpace(exact.Value)) return exact.Value;
        }
        foreach (var item in map)
        {
            var normalized = NormalizeName(item.Key);
            if (keywords.Any(k => normalized.Contains(NormalizeName(k), StringComparison.OrdinalIgnoreCase)) && !string.IsNullOrWhiteSpace(item.Value))
                return item.Value;
        }
        return null;
    }

    private static string? InferCode(IReadOnlyDictionary<string, string> map, string panelTitle)
    {
        foreach (var value in map.Values)
        {
            if (Regex.IsMatch(value ?? string.Empty, @"^(?:ISO8583[-_: ]*)?\d{1,3}$", RegexOptions.IgnoreCase))
                return value;
        }
        var m = Regex.Match(panelTitle, @"(?<!\d)(\d{2,3})(?!\d)");
        return m.Success ? m.Groups[1].Value : null;
    }

    private static string InferSource(string panelTitle) => VposErrorCatalog.NormalizeSource(panelTitle);

    private static long ParseCount(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return 1;
        var clean = value.Replace(".", string.Empty).Replace(",", ".");
        return double.TryParse(clean, NumberStyles.Any, CultureInfo.InvariantCulture, out var d) && d > 0
            ? Math.Max(1, (long)Math.Round(d))
            : 1;
    }

    private static DateTime? ParseDate(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;
        if (long.TryParse(value, out var epoch))
        {
            try
            {
                return epoch > 100000000000
                    ? DateTimeOffset.FromUnixTimeMilliseconds(epoch).LocalDateTime
                    : DateTimeOffset.FromUnixTimeSeconds(epoch).LocalDateTime;
            }
            catch { }
        }
        return DateTime.TryParse(value, CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal, out var dt) ||
               DateTime.TryParse(value, CultureInfo.GetCultureInfo("tr-TR"), DateTimeStyles.AssumeLocal, out dt)
            ? dt
            : null;
    }

    private static string ElementToString(JsonElement element) => element.ValueKind switch
    {
        JsonValueKind.String => element.GetString() ?? string.Empty,
        JsonValueKind.Number => element.GetRawText(),
        JsonValueKind.True => "true",
        JsonValueKind.False => "false",
        JsonValueKind.Null => string.Empty,
        _ => element.ToString()
    };

    private static bool MatchesAny(string text, IEnumerable<string> keywords) =>
        keywords.Any(x => text.Contains(x, StringComparison.OrdinalIgnoreCase));

    private static bool Contains(string? value, string? term) =>
        !string.IsNullOrWhiteSpace(value) && !string.IsNullOrWhiteSpace(term) && value.Contains(term, StringComparison.OrdinalIgnoreCase);

    private static string NormalizeName(string value) =>
        Regex.Replace(value ?? string.Empty, @"[^a-zA-Z0-9ğüşöçıİĞÜŞÖÇ@]", string.Empty).ToLowerInvariant();

    private static string? ReadString(JsonElement element, string property) =>
        element.ValueKind == JsonValueKind.Object && element.TryGetProperty(property, out var value)
            ? value.ValueKind == JsonValueKind.String ? value.GetString() : value.ToString()
            : null;

    private static int? ReadInt(JsonElement element, string property) =>
        element.ValueKind == JsonValueKind.Object && element.TryGetProperty(property, out var value) && value.TryGetInt32(out var i) ? i : null;

    private static string TrimMessage(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return "yanıt yok";
        var x = Regex.Replace(value, @"\s+", " ").Trim();
        return x.Length <= 240 ? x : x[..240] + "...";
    }

    private static string Friendly(Exception ex)
    {
        if (ex is TaskCanceledException) return "Grafana isteği zaman aşımına uğradı.";
        if (ex is HttpRequestException) return "Grafana sunucusuna ulaşılamadı: " + ex.Message;
        return ex.Message;
    }

    private sealed class GrafanaAuth
    {
        public string? BasicToken { get; init; }
        public string? CookieHeader { get; init; }
    }

    private sealed record DashboardAddress(string BaseUrl, string Uid, string OriginalDashboardUrl);
}
