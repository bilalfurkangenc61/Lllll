using BtOperasyonTakip.Data;
using BtOperasyonTakip.Dtos;
using BtOperasyonTakip.Models;
using BtOperasyonTakip.Security;
using BtOperasyonTakip.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using System.Globalization;
using System.Text;

namespace BtOperasyonTakip.Controllers
{
    [Authorize(Roles = AppRoles.VposKullanici + "," + AppRoles.Operasyon + "," + AppRoles.OperasyonSuperAdmin + ",Operasyon Süper Admin,Operasyon Super Admin," + AppRoles.Admin)]
    public class VposController : Controller
    {
        private const string OperasyonCustomerParamType = "UrunMusteri:OPERASYON";
        private const string VposCustomerParamType = "UrunMusteri:VPOS";
        private const string MobilCustomerParamType = "UrunMusteri:MOBIL";
        private const string ProductConfiguredParamType = "UrunMusteri:YAPILANDIRILDI";
        private const string MusteriVknParamType = "MusteriEk:VKN";
        private const string MusteriHariciIdParamType = "MusteriEk:HARICI_ID";
        private const string VposTaskPrefix = "[VPOS] ";
        private const string VposErrorParamType = "UrunHata:VPOS";
        private readonly AppDbContext _context;
        private readonly IVposGrafanaDashboardGateway _dashboardGateway;
        private readonly IVposMonitoringCredentialStore _credentialStore;
        private readonly IMemoryCache _cache;

        public VposController(
            AppDbContext context,
            IVposGrafanaDashboardGateway dashboardGateway,
            IVposMonitoringCredentialStore credentialStore,
            IMemoryCache cache)
        {
            _context = context;
            _dashboardGateway = dashboardGateway;
            _credentialStore = credentialStore;
            _cache = cache;
        }

        [HttpGet]
        public IActionResult Index()
        {
            return RedirectToAction(nameof(AnaSayfa));
        }


        // ============================================================
        // VPOS CANLI MONITORING - MEVCUT VPOS ALANININ İÇİNDE
        // DB entity/model değişikliği yok. Veriler Grafana dashboard
        // sorguları üzerinden alınır; Elastic/Kibana linki dashboard
        // data-link tanımından okunur.
        // ============================================================

        [HttpGet]
        public async Task<IActionResult> AnaSayfa(bool yenile = false, CancellationToken cancellationToken = default)
        {
            var userId = GetCurrentUserId();
            if (userId <= 0) return Forbid();

            var credential = await _credentialStore.GetAsync(userId, cancellationToken);
            var vm = new VposOverviewVm
            {
                CredentialsSaved = credential != null,
                Username = credential?.Username,
                DashboardUrl = credential?.DashboardUrl
            };

            if (credential == null)
            {
                vm.Message = "Grafana dashboard bağlantısı için bilgilerinizi bir kez kaydedin.";
                return View(vm);
            }

            // Ana ekranın firma grafiği işlem panellerinden, hata grafiği hata panellerinden
            // ayrı ayrı beslenir. Böylece hata satırları firma işlem sayısına karışmaz.
            var transactionCacheKey = $"vpos:overview:transactions:{userId}";
            var errorCacheKey = $"vpos:overview:errors:{userId}";
            VposMonitoringResult? transactions = null;
            VposMonitoringResult? errors = null;

            if (!yenile)
            {
                _cache.TryGetValue(transactionCacheKey, out transactions);
                _cache.TryGetValue(errorCacheKey, out errors);
            }

            var now = DateTime.Today;
            var firstMonth = new DateTime(now.Year, now.Month, 1).AddMonths(-5);
            var filter = new VposMonitoringFilter
            {
                From = firstMonth,
                To = now,
                PageSize = 250
            };

            if (transactions == null)
            {
                transactions = await _dashboardGateway.QueryAsync(credential, filter, "transactions", cancellationToken);
                if (transactions.Success)
                    _cache.Set(transactionCacheKey, transactions, TimeSpan.FromMinutes(15));
            }

            if (errors == null)
            {
                errors = await _dashboardGateway.QueryAsync(credential, filter, "errors", cancellationToken);
                if (errors.Success)
                    _cache.Set(errorCacheKey, errors, TimeSpan.FromMinutes(15));
            }

            vm.Connected = transactions.Success || errors.Success;
            vm.Message = vm.Connected
                ? $"Grafana güncellendi. İşlem: {transactions.Message} Hata: {errors.Message}"
                : $"İşlem panelleri: {transactions.Message} Hata panelleri: {errors.Message}";
            vm.DashboardTitle = transactions.DashboardTitle ?? errors.DashboardTitle;
            vm.RetrievedAt = new[] { transactions.RetrievedAt, errors.RetrievedAt }.Max();

            vm.TotalCompanyCount = transactions.Companies.Count;
            var currentMonthStart = new DateTime(now.Year, now.Month, 1);
            vm.ThisMonthActiveCompanyCount = transactions.Rows
                .Where(x => x.Timestamp.HasValue && x.Timestamp.Value >= currentMonthStart)
                .Select(x => x.Customer)
                .Where(x => !string.IsNullOrWhiteSpace(x) && x != "-")
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .Count();
            vm.TotalRowCount = transactions.Rows.Sum(x => Math.Max(1, x.Count));
            vm.TotalErrorCount = errors.Rows.Sum(x => Math.Max(1, x.Count));
            vm.TopCompanies = transactions.Companies.Take(5).ToList();
            vm.TopErrors = errors.Errors.Take(5).ToList();
            vm.Sources = errors.Sources.Take(10).ToList();

            var months = Enumerable.Range(0, 6).Select(i => firstMonth.AddMonths(i)).ToList();
            vm.Months = months.Select(x => x.ToString("MMM yy", CultureInfo.GetCultureInfo("tr-TR"))).ToList();
            foreach (var company in vm.TopCompanies)
            {
                var series = new VposCompanyMonthlySeries { Company = company.Key };
                foreach (var month in months)
                {
                    var next = month.AddMonths(1);
                    series.Values.Add(transactions.Rows
                        .Where(x => x.Timestamp.HasValue &&
                                    x.Timestamp.Value >= month && x.Timestamp.Value < next &&
                                    string.Equals(x.Customer, company.Key, StringComparison.OrdinalIgnoreCase))
                        .Sum(x => Math.Max(1, x.Count)));
                }
                vm.TopCompanyMonthlySeries.Add(series);
            }

            return View(vm);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> GrafanaBaglan(
            string dashboardUrl,
            string grafanaUsername,
            string grafanaPassword,
            string? elasticUrl,
            CancellationToken cancellationToken = default)
        {
            var userId = GetCurrentUserId();
            if (userId <= 0) return Forbid();

            dashboardUrl = (dashboardUrl ?? string.Empty).Trim();
            grafanaUsername = (grafanaUsername ?? string.Empty).Trim();
            grafanaPassword ??= string.Empty;
            elasticUrl = string.IsNullOrWhiteSpace(elasticUrl) ? string.Empty : elasticUrl.Trim();

            if (string.IsNullOrWhiteSpace(dashboardUrl) || string.IsNullOrWhiteSpace(grafanaUsername) || string.IsNullOrWhiteSpace(grafanaPassword))
            {
                TempData["GrafanaError"] = "Grafana sunucu adresi, kullanıcı adı ve şifre zorunludur.";
                return RedirectToAction(nameof(AnaSayfa));
            }

            var credential = new VposMonitoringCredential
            {
                DashboardUrl = dashboardUrl,
                GrafanaUrl = GetGrafanaBaseUrl(dashboardUrl),
                ElasticUrl = elasticUrl,
                Username = grafanaUsername,
                Password = grafanaPassword
            };

            var test = await _dashboardGateway.TestAsync(credential, cancellationToken);
            if (!test.Success)
            {
                TempData["GrafanaError"] = test.Message;
                return RedirectToAction(nameof(AnaSayfa));
            }

            await _credentialStore.SaveAsync(userId, credential, cancellationToken);
            ClearMonitoringCache(userId);
            TempData["GrafanaOk"] = test.Message;
            return RedirectToAction(nameof(AnaSayfa), new { yenile = true });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> GrafanaUnut(CancellationToken cancellationToken = default)
        {
            var userId = GetCurrentUserId();
            if (userId <= 0) return Forbid();
            await _credentialStore.DeleteAsync(userId, cancellationToken);
            ClearMonitoringCache(userId);
            TempData["GrafanaOk"] = "Kişisel Grafana bağlantı bilginiz silindi.";
            return RedirectToAction(nameof(AnaSayfa));
        }

        [HttpGet]
        public async Task<IActionResult> GrafanaTest(CancellationToken cancellationToken = default)
        {
            var userId = GetCurrentUserId();
            if (userId <= 0) return Forbid();
            var credential = await _credentialStore.GetAsync(userId, cancellationToken);
            if (credential == null) return Json(new { basarili = false, mesaj = "Kayıtlı Grafana bağlantısı yok." });
            var test = await _dashboardGateway.TestAsync(credential, cancellationToken);
            return Json(new { basarili = test.Success, mesaj = test.Message, dashboard = test.DashboardTitle, panelSayisi = test.PanelCount });
        }

        [HttpGet]
        public async Task<IActionResult> Hatalar(
            [FromQuery] VposMonitoringFilter filter,
            bool yenile = false,
            CancellationToken cancellationToken = default)
        {
            var userId = GetCurrentUserId();
            if (userId <= 0) return Forbid();
            var normalized = filter.Normalized();
            var credential = await _credentialStore.GetAsync(userId, cancellationToken);
            var vm = new VposMonitoringPageVm
            {
                Filter = normalized,
                CredentialsSaved = credential != null,
                DashboardUrl = credential?.DashboardUrl,
                Username = credential?.Username,
                Refreshed = yenile
            };

            if (credential == null)
            {
                vm.Data.Message = "Önce VPOS Ana Sayfa'dan Grafana dashboard bağlantınızı kaydedin.";
                return View(vm);
            }

            var cacheKey = $"vpos:errors:{userId}:{normalized.CacheKey()}";
            VposMonitoringResult? data = null;
            if (!yenile)
                _cache.TryGetValue(cacheKey, out data);

            if (yenile)
            {
                data = await _dashboardGateway.QueryAsync(credential, normalized, "errors", cancellationToken);
                if (data.Success) _cache.Set(cacheKey, data, TimeSpan.FromMinutes(30));
            }
            else if (data == null)
            {
                data = new VposMonitoringResult
                {
                    Success = false,
                    Message = "Filtrelerinizi seçip Verileri Güncelle butonuna basın. Canlı veri yalnızca Grafana dashboard üzerinden çekilir."
                };
            }

            FillPage(vm, data);
            return View(vm);
        }

        [HttpGet]
        public async Task<IActionResult> CanliHataDetay(
            string? q,
            string? customer,
            string? code,
            string? source,
            DateTime? from,
            DateTime? to,
            CancellationToken cancellationToken = default)
        {
            var userId = GetCurrentUserId();
            if (userId <= 0) return Forbid();
            var credential = await _credentialStore.GetAsync(userId, cancellationToken);
            if (credential == null) return RedirectToAction(nameof(AnaSayfa));

            var filter = new VposMonitoringFilter
            {
                Q = q,
                Customer = customer,
                Code = code,
                Source = source,
                From = from,
                To = to,
                PageSize = 250
            }.Normalized();

            var data = await _dashboardGateway.QueryAsync(credential, filter, "errors", cancellationToken);
            var vm = new VposMonitoringPageVm
            {
                Filter = filter,
                Data = data,
                CredentialsSaved = true,
                DashboardUrl = credential.DashboardUrl,
                Username = credential.Username,
                Refreshed = true
            };
            FillPage(vm, data);
            return View(vm);
        }

        [HttpGet]
        public async Task<IActionResult> HataRaporu(
            [FromQuery] VposMonitoringFilter filter,
            CancellationToken cancellationToken = default)
        {
            var userId = GetCurrentUserId();
            if (userId <= 0) return Forbid();
            var credential = await _credentialStore.GetAsync(userId, cancellationToken);
            if (credential == null) return RedirectToAction(nameof(AnaSayfa));

            var data = await _dashboardGateway.QueryAsync(credential, filter.Normalized(), "errors", cancellationToken);
            if (!data.Success)
            {
                TempData["VposError"] = data.Message;
                return RedirectToAction(nameof(Hatalar));
            }

            var bytes = VposExcelExportService.BuildErrors(data.Rows);
            return File(
                bytes,
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                $"VPOS_Grafana_Hata_Raporu_{DateTime.Now:yyyyMMdd_HHmm}.xlsx");
        }

        [HttpGet]
        public async Task<IActionResult> Kesintiler(
            [FromQuery] VposMonitoringFilter filter,
            bool yenile = false,
            CancellationToken cancellationToken = default)
        {
            var userId = GetCurrentUserId();
            if (userId <= 0) return Forbid();
            var normalized = filter.Normalized();
            var credential = await _credentialStore.GetAsync(userId, cancellationToken);
            var vm = new VposMonitoringPageVm
            {
                Filter = normalized,
                CredentialsSaved = credential != null,
                DashboardUrl = credential?.DashboardUrl,
                Username = credential?.Username,
                Refreshed = yenile
            };

            if (credential == null)
            {
                vm.Data.Message = "Önce VPOS Ana Sayfa'dan Grafana dashboard bağlantınızı kaydedin.";
                return View(vm);
            }

            var cacheKey = $"vpos:outages:{userId}:{normalized.CacheKey()}";
            VposMonitoringResult? data = null;
            if (!yenile) _cache.TryGetValue(cacheKey, out data);
            if (yenile)
            {
                data = await _dashboardGateway.QueryAsync(credential, normalized, "outages", cancellationToken);
                if (data.Success) _cache.Set(cacheKey, data, TimeSpan.FromMinutes(15));
            }
            else if (data == null)
            {
                data = new VposMonitoringResult
                {
                    Message = "Tarih/müşteri filtrelerini seçip Verileri Güncelle butonuna basın. Kesinti verisi Grafana'daki ilgili panellerden alınır."
                };
            }

            FillPage(vm, data);
            return View(vm);
        }

        private static void FillPage(VposMonitoringPageVm vm, VposMonitoringResult data)
        {
            vm.Data = data;
            vm.TotalRows = data.Rows.Count;
            vm.CustomerOptions = data.Rows.Select(x => x.Customer).Where(x => !string.IsNullOrWhiteSpace(x) && x != "-").Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(x => x).ToList();
            vm.SourceOptions = data.Rows.Select(x => x.Source).Where(x => !string.IsNullOrWhiteSpace(x) && x != "-").Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(x => x).ToList();
            vm.CodeOptions = data.Rows.Select(x => x.NormalizedCode).Where(x => !string.IsNullOrWhiteSpace(x) && x != "-").Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(x => x).ToList();
            var pageSize = Math.Clamp(vm.Filter.PageSize, 10, 250);
            vm.TotalPages = Math.Max(1, (int)Math.Ceiling(vm.TotalRows / (double)pageSize));
            vm.Filter.Page = Math.Clamp(vm.Filter.Page, 1, vm.TotalPages);
            vm.PageRows = data.Rows.Skip((vm.Filter.Page - 1) * pageSize).Take(pageSize).ToList();
        }

        private void ClearMonitoringCache(int userId)
        {
            // IMemoryCache prefix silme sunmadığı için bilinen özet anahtarı temizlenir.
            // Filtre anahtarları kısa ömürlüdür ve bağlantı değişince yeni sorguda üzerine yazılır.
            _cache.Remove($"vpos:overview:transactions:{userId}");
            _cache.Remove($"vpos:overview:errors:{userId}");
        }

        private static string GetGrafanaBaseUrl(string dashboardUrl)
        {
            if (!Uri.TryCreate(dashboardUrl, UriKind.Absolute, out var uri)) return string.Empty;
            var segments = uri.AbsolutePath.Split('/', StringSplitOptions.RemoveEmptyEntries);
            var marker = Array.FindIndex(segments, x => x.Equals("d", StringComparison.OrdinalIgnoreCase) || x.Equals("d-solo", StringComparison.OrdinalIgnoreCase));
            var prefix = marker <= 0 ? string.Empty : "/" + string.Join('/', segments.Take(marker));
            return $"{uri.Scheme}://{uri.Authority}{prefix}".TrimEnd('/');
        }

        [HttpGet]
        public async Task<IActionResult> Musteriler(string? q)
        {
            var ids = GetVposMusteriIds();
            var query = _context.Musteriler
                .AsNoTracking()
                .Where(x => ids.Contains(x.MusteriID));

            if (!string.IsNullOrWhiteSpace(q))
            {
                var term = q.Trim();
                query = query.Where(x =>
                    (x.Firma != null && x.Firma.Contains(term)) ||
                    (x.SiteUrl != null && x.SiteUrl.Contains(term)) ||
                    (x.FirmaYetkilisi != null && x.FirmaYetkilisi.Contains(term)));
            }

            ViewBag.Q = q;
            return View(await query.OrderBy(x => x.Firma).ToListAsync());
        }

        [HttpGet]
        public async Task<IActionResult> YeniMusteri()
        {
            await LoadYeniMusteriViewDataAsync();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> YeniMusteri(
            string? firma,
            string? siteUrl,
            string? teknoloji,
            string? durum,
            string? firmaYetkilisi,
            string? telefon,
            string? aciklama,
            string? vkn,
            string? hariciMusteriId)
        {
            firma = (firma ?? string.Empty).Trim();
            siteUrl = string.IsNullOrWhiteSpace(siteUrl) ? null : siteUrl.Trim();
            teknoloji = string.IsNullOrWhiteSpace(teknoloji) ? null : teknoloji.Trim();
            durum = (durum ?? string.Empty).Trim();
            firmaYetkilisi = string.IsNullOrWhiteSpace(firmaYetkilisi) ? null : firmaYetkilisi.Trim();
            telefon = string.IsNullOrWhiteSpace(telefon) ? null : telefon.Trim();
            aciklama = string.IsNullOrWhiteSpace(aciklama) ? null : aciklama.Trim();
            vkn = string.IsNullOrWhiteSpace(vkn) ? null : vkn.Trim();
            hariciMusteriId = string.IsNullOrWhiteSpace(hariciMusteriId) ? null : hariciMusteriId.Trim();

            if (string.IsNullOrWhiteSpace(firma))
                ModelState.AddModelError(nameof(firma), "Firma adı zorunludur.");

            if (!string.IsNullOrWhiteSpace(vkn) && vkn.Length > 10)
                ModelState.AddModelError(nameof(vkn), "VKN 10 karakterden uzun olamaz.");

            if (!string.IsNullOrWhiteSpace(hariciMusteriId) && hariciMusteriId.Length > 100)
                ModelState.AddModelError(nameof(hariciMusteriId), "Harici müşteri ID 100 karakterden uzun olamaz.");

            var durumlar = await GetMusteriDurumlariAsync();
            if (string.IsNullOrWhiteSpace(durum))
            {
                durum = durumlar.FirstOrDefault(x => string.Equals(x, "Beklemede", StringComparison.OrdinalIgnoreCase))
                        ?? durumlar.FirstOrDefault()
                        ?? "Beklemede";
            }
            else if (durumlar.Count > 0 && !durumlar.Contains(durum, StringComparer.OrdinalIgnoreCase))
            {
                ModelState.AddModelError(nameof(durum), "Geçerli bir müşteri durumu seçiniz.");
            }

            var atama = await GetLeastLoadedOperasyonUserAsync();
            if (atama.User == null)
                ModelState.AddModelError(string.Empty, "Entegrasyon işi atanamadı. Operasyon rolünde en az bir aktif kullanıcı bulunmalıdır.");

            if (!ModelState.IsValid)
            {
                await LoadYeniMusteriViewDataAsync();
                ViewBag.Firma = firma;
                ViewBag.SiteUrl = siteUrl;
                ViewBag.Teknoloji = teknoloji;
                ViewBag.Durum = durum;
                ViewBag.FirmaYetkilisi = firmaYetkilisi;
                ViewBag.Telefon = telefon;
                ViewBag.Aciklama = aciklama;
                ViewBag.VKN = vkn;
                ViewBag.HariciMusteriId = hariciMusteriId;
                return View();
            }

            var currentUserId = GetCurrentUserId();
            var currentUserName = GetCurrentUserDisplayName();
            var assignedName = GetDisplayName(atama.User!);
            var now = DateTime.Now;

            await using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                var musteri = new Musteri
                {
                    Firma = firma,
                    SiteUrl = siteUrl,
                    Teknoloji = teknoloji,
                    Durum = durum,
                    DurumDegisiklikTarihi = now,
                    DokumanKontrolBaslangicTarihi = null,
                    DokumanGonderimSayisi = 0,
                    DokumanGonderildiMi = null,
                    TalepSahibi = currentUserName,
                    Telefon = telefon,
                    Aciklama = aciklama,
                    KayitTarihi = now,
                    FirmaYetkilisi = firmaYetkilisi,
                    Kekleyen = currentUserName,
                    Kaynak = "VPOS"
                };

                _context.Musteriler.Add(musteri);
                await _context.SaveChangesAsync();

                var musteriIdText = musteri.MusteriID.ToString(CultureInfo.InvariantCulture);
                _context.Parametreler.Add(new Parametre { Tur = ProductConfiguredParamType, ParAdi = musteriIdText });
                _context.Parametreler.Add(new Parametre { Tur = VposCustomerParamType, ParAdi = musteriIdText });

                SaveMusteriEkAlanlariNoSave(musteri.MusteriID, vkn, hariciMusteriId);

                var jiraId = currentUserId > 0
                    ? $"VPOS-{currentUserId}-{now:yyyyMMddHHmmssfff}"
                    : $"VPOS-{now:yyyyMMddHHmmssfff}";

                var task = new JiraTask
                {
                    MusteriID = musteri.MusteriID,
                    MusteriAdi = musteri.Firma ?? string.Empty,
                    JiraId = jiraId,
                    TalepKonusu = VposTaskPrefix + "Yeni müşteri entegrasyonu - " + (musteri.Firma ?? string.Empty),
                    TalepTuru = "Entegrasyon",
                    TalepAcan = currentUserName,
                    Durum = "Aktif",
                    TakipEden = assignedName,
                    OlusturmaTarihi = now
                };

                _context.JiraTasks.Add(task);
                await _context.SaveChangesAsync();

                var notParts = new List<string>
                {
                    "[VPOS TALEP] Yeni VPOS müşteri kaydı oluşturuldu ve entegrasyon işi otomatik açıldı.",
                    $"Operations assignee selected by workload: {assignedName}."
                };
                if (!string.IsNullOrWhiteSpace(aciklama))
                    notParts.Add("Müşteri notu: " + aciklama);

                _context.JiraYorumlar.Add(new JiraYorum
                {
                    JiraTaskId = task.Id,
                    YorumMetni = string.Join(Environment.NewLine, notParts),
                    Ekleyen = currentUserName,
                    Tarih = now
                });
                await _context.SaveChangesAsync();

                await transaction.CommitAsync();

                TempData["JiraOk"] = $"VPOS customer {musteri.Firma} was created. The integration work item was assigned to {assignedName} based on workload (previous active workload: {atama.Workload}).";
                return RedirectToAction("Vpos", "Takip", new { selectedTaskId = task.Id });
            }
            catch (Exception)
            {
                await transaction.RollbackAsync();
                ModelState.AddModelError(string.Empty, "Müşteri ve entegrasyon işi oluşturulamadı. Lütfen tekrar deneyin.");
                await LoadYeniMusteriViewDataAsync();
                ViewBag.Firma = firma;
                ViewBag.SiteUrl = siteUrl;
                ViewBag.Teknoloji = teknoloji;
                ViewBag.Durum = durum;
                ViewBag.FirmaYetkilisi = firmaYetkilisi;
                ViewBag.Telefon = telefon;
                ViewBag.Aciklama = aciklama;
                ViewBag.VKN = vkn;
                ViewBag.HariciMusteriId = hariciMusteriId;
                return View();
            }
        }

        [HttpGet]
        public async Task<IActionResult> DuzenleMusteri(int id)
        {
            if (!GetVposMusteriIds().Contains(id))
                return NotFound();

            var musteri = await _context.Musteriler
                .AsNoTracking()
                .FirstOrDefaultAsync(x => x.MusteriID == id);

            if (musteri == null)
                return NotFound();

            await LoadYeniMusteriViewDataAsync();
            var ek = GetMusteriEkAlanlari(id);
            ViewBag.VKN = ek.Vkn;
            ViewBag.HariciMusteriId = ek.HariciMusteriId;

            return View(musteri);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DuzenleMusteri(
            int musteriId,
            string? firma,
            string? siteUrl,
            string? teknoloji,
            string? durum,
            string? firmaYetkilisi,
            string? telefon,
            string? aciklama,
            string? vkn,
            string? hariciMusteriId)
        {
            if (!GetVposMusteriIds().Contains(musteriId))
                return NotFound();

            var musteri = await _context.Musteriler.FirstOrDefaultAsync(x => x.MusteriID == musteriId);
            if (musteri == null)
                return NotFound();

            firma = (firma ?? string.Empty).Trim();
            siteUrl = string.IsNullOrWhiteSpace(siteUrl) ? null : siteUrl.Trim();
            teknoloji = string.IsNullOrWhiteSpace(teknoloji) ? null : teknoloji.Trim();
            durum = (durum ?? string.Empty).Trim();
            firmaYetkilisi = string.IsNullOrWhiteSpace(firmaYetkilisi) ? null : firmaYetkilisi.Trim();
            telefon = string.IsNullOrWhiteSpace(telefon) ? null : telefon.Trim();
            aciklama = string.IsNullOrWhiteSpace(aciklama) ? null : aciklama.Trim();
            vkn = string.IsNullOrWhiteSpace(vkn) ? null : vkn.Trim();
            hariciMusteriId = string.IsNullOrWhiteSpace(hariciMusteriId) ? null : hariciMusteriId.Trim();

            if (string.IsNullOrWhiteSpace(firma))
                ModelState.AddModelError(nameof(firma), "Firma adı zorunludur.");
            if (!string.IsNullOrWhiteSpace(vkn) && vkn.Length > 10)
                ModelState.AddModelError(nameof(vkn), "VKN 10 karakterden uzun olamaz.");
            if (!string.IsNullOrWhiteSpace(hariciMusteriId) && hariciMusteriId.Length > 100)
                ModelState.AddModelError(nameof(hariciMusteriId), "Harici müşteri ID 100 karakterden uzun olamaz.");

            var durumlar = await GetMusteriDurumlariAsync();
            if (durumlar.Count > 0 && !durumlar.Contains(durum, StringComparer.OrdinalIgnoreCase))
                ModelState.AddModelError(nameof(durum), "Geçerli bir müşteri durumu seçiniz.");

            if (!ModelState.IsValid)
            {
                await LoadYeniMusteriViewDataAsync();
                ViewBag.VKN = vkn;
                ViewBag.HariciMusteriId = hariciMusteriId;

                musteri.Firma = firma;
                musteri.SiteUrl = siteUrl;
                musteri.Teknoloji = teknoloji;
                musteri.Durum = durum;
                musteri.FirmaYetkilisi = firmaYetkilisi;
                musteri.Telefon = telefon;
                musteri.Aciklama = aciklama;
                return View(musteri);
            }

            var eskiDurum = musteri.Durum ?? string.Empty;
            var durumDegisti = !string.Equals(eskiDurum.Trim(), durum, StringComparison.OrdinalIgnoreCase);

            musteri.Firma = firma;
            musteri.SiteUrl = siteUrl;
            musteri.Teknoloji = teknoloji;
            musteri.Durum = durum;
            musteri.FirmaYetkilisi = firmaYetkilisi;
            musteri.Telefon = telefon;
            musteri.Aciklama = aciklama;

            if (durumDegisti)
            {
                musteri.DurumDegisiklikTarihi = DateTime.Now;
                musteri.DokumanGonderildiMi = null;
                musteri.DokumanGonderimSayisi = 0;
                musteri.DokumanKontrolBaslangicTarihi = musteri.DurumDegisiklikTarihi;

                _context.MusteriDurumGecmisleri.Add(new MusteriDurumGecmisi
                {
                    MusteriID = musteri.MusteriID,
                    EskiDurum = eskiDurum,
                    YeniDurum = durum,
                    Aciklama = aciklama ?? "VPOS müşteri ekranından güncellendi.",
                    Tarih = DateTime.Now,
                    DegistirenKullanici = User.Identity?.Name
                });
            }

            SetMusteriEkAlanlariNoSave(musteriId, vkn, hariciMusteriId);
            await _context.SaveChangesAsync();

            TempData["VposOk"] = "Müşteri güncellendi. Değişiklik tüm müşteri ekranlarına yansıdı.";
            return RedirectToAction(nameof(Musteriler));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> VpostanCikar(int id)
        {
            var idText = id.ToString(CultureInfo.InvariantCulture);
            var vposMarkers = await _context.Parametreler
                .Where(x => x.Tur == VposCustomerParamType && x.ParAdi == idText)
                .ToListAsync();

            if (vposMarkers.Count == 0)
            {
                TempData["VposError"] = "Müşteri VPOS listesinde bulunamadı.";
                return RedirectToAction(nameof(Musteriler));
            }

            var digerUrunVar = await _context.Parametreler.AnyAsync(x =>
                x.ParAdi == idText &&
                (x.Tur == OperasyonCustomerParamType || x.Tur == MobilCustomerParamType));

            if (!digerUrunVar)
            {
                TempData["VposError"] = "Bu müşterinin tek ürünü VPOS. Önce PF/Cüzdan ürünü ekleyin veya 'Tamamen Sil' kullanın.";
                return RedirectToAction(nameof(Musteriler));
            }

            _context.Parametreler.RemoveRange(vposMarkers);
            await _context.SaveChangesAsync();

            TempData["VposOk"] = "Müşteri VPOS listesinden çıkarıldı. Ana müşteri kaydı korunuyor.";
            return RedirectToAction(nameof(Musteriler));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> MusteriyiTamamenSil(int id)
        {
            if (!GetVposMusteriIds().Contains(id))
            {
                TempData["VposError"] = "Müşteri VPOS listesinde bulunamadı.";
                return RedirectToAction(nameof(Musteriler));
            }

            var result = await MusteriSilmeHelper.TamamenSilAsync(_context, id);
            TempData[result.Success ? "VposOk" : "VposError"] = result.Message;
            return RedirectToAction(nameof(Musteriler));
        }

        [HttpGet]
        public async Task<IActionResult> Yeni(string? kayitTipi = null)
        {
            await LoadYeniViewDataAsync();
            ViewBag.KayitTipi = string.Equals(kayitTipi, "HATA", StringComparison.OrdinalIgnoreCase)
                ? "HATA"
                : "IS";
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Yeni(
            string kayitTipi,
            int? musteriId,
            string? konu,
            string? aciklama,
            string? kategori)
        {
            kayitTipi = (kayitTipi ?? string.Empty).Trim().ToUpperInvariant();
            konu = (konu ?? string.Empty).Trim();
            aciklama = (aciklama ?? string.Empty).Trim();
            kategori = (kategori ?? string.Empty).Trim();

            if (kayitTipi != "IS" && kayitTipi != "HATA")
                ModelState.AddModelError(nameof(kayitTipi), "Kayıt tipi seçiniz.");

            var vposIds = GetVposMusteriIds();
            Musteri? musteri = null;

            if (!musteriId.HasValue || !vposIds.Contains(musteriId.Value))
            {
                ModelState.AddModelError(nameof(musteriId), "VPOS müşterisi seçiniz.");
            }
            else
            {
                musteri = await _context.Musteriler
                    .AsNoTracking()
                    .FirstOrDefaultAsync(x => x.MusteriID == musteriId.Value);

                if (musteri == null)
                    ModelState.AddModelError(nameof(musteriId), "Müşteri bulunamadı.");
            }

            if (string.IsNullOrWhiteSpace(konu))
                ModelState.AddModelError(nameof(konu), kayitTipi == "HATA" ? "Hata adı zorunludur." : "İş konusu zorunludur.");

            if (kayitTipi == "HATA" && string.IsNullOrWhiteSpace(kategori))
                ModelState.AddModelError(nameof(kategori), "Hata kategorisi zorunludur.");

            var atama = await GetLeastLoadedOperasyonUserAsync();
            var atanacak = atama.User;
            if (atanacak == null)
                ModelState.AddModelError(string.Empty, "İş yoğunluğuna göre atama yapılamadı. Operasyon rolünde en az bir kullanıcı olmalı.");

            if (!ModelState.IsValid)
            {
                await LoadYeniViewDataAsync();
                ViewBag.KayitTipi = kayitTipi;
                ViewBag.SeciliMusteriId = musteriId;
                ViewBag.Konu = konu;
                ViewBag.Aciklama = aciklama;
                ViewBag.Kategori = kategori;
                return View();
            }

            var currentUserId = GetCurrentUserId();
            var currentUserName = GetCurrentUserDisplayName();
            var assignedName = GetDisplayName(atanacak!);

            if (kayitTipi == "HATA")
            {
                
                
                
                
                
                var hata = new Hata
                {
                    HataAdi = konu,
                    HataAciklama = aciklama,
                    KategoriBilgisi = kategori,
                    OlusturanUserId = atanacak!.Id,
                    OlusturanKullaniciAdi = assignedName,
                    OlusturmaTarihi = DateTime.Now,
                    Durum = "Açık",
                    SecilenHataId = currentUserId > 0 ? -currentUserId : null,
                    OperasyonCevabi = string.Empty,
                    CevaplayanKullaniciAdi = string.Empty,
                    MusteriID = musteriId
                };

                _context.Hatalar.Add(hata);
                await _context.SaveChangesAsync();

                _context.Parametreler.Add(new Parametre
                {
                    Tur = VposErrorParamType,
                    ParAdi = hata.Id.ToString(CultureInfo.InvariantCulture)
                });
                await _context.SaveChangesAsync();

                TempData["VposOk"] = $"The issue was created and assigned to {assignedName} based on workload (previous active workload: {atama.Workload}).";
                return RedirectToAction(nameof(YerelHatalar));
            }

            var jiraId = currentUserId > 0
                ? $"VPOS-{currentUserId}-{DateTime.Now:yyyyMMddHHmmssfff}"
                : $"VPOS-{DateTime.Now:yyyyMMddHHmmssfff}";

            var task = new JiraTask
            {
                MusteriID = musteriId,
                MusteriAdi = musteri?.Firma ?? string.Empty,
                JiraId = jiraId,
                TalepKonusu = VposTaskPrefix + konu,
                TalepTuru = "Entegrasyon",
                TalepAcan = currentUserName,
                Durum = "Aktif",
                TakipEden = assignedName,
                OlusturmaTarihi = DateTime.Now
            };

            _context.JiraTasks.Add(task);
            await _context.SaveChangesAsync();

            if (!string.IsNullOrWhiteSpace(aciklama))
            {
                _context.JiraYorumlar.Add(new JiraYorum
                {
                    JiraTaskId = task.Id,
                    YorumMetni = "[VPOS TALEP] " + aciklama,
                    Ekleyen = currentUserName,
                    Tarih = DateTime.Now
                });
                await _context.SaveChangesAsync();
            }

            TempData["JiraOk"] = $"The integration work item was created and assigned to {assignedName} based on workload (previous active workload: {atama.Workload}).";
            return RedirectToAction("Vpos", "Takip", new { selectedTaskId = task.Id });
        }

        [HttpGet]
        public async Task<IActionResult> Islerim(string? q, string? durum)
        {
            var currentUserId = GetCurrentUserId();
            var currentUserName = GetCurrentUserDisplayName();
            var ownerPrefix = GetVposTaskOwnerPrefix(currentUserId);

            var query = _context.JiraTasks
                .AsNoTracking()
                .Include(x => x.Yorumlar)
                .Where(x => x.TalepKonusu != null && x.TalepKonusu.StartsWith(VposTaskPrefix))
                .Where(x => x.TalepAcan == currentUserName ||
                            (ownerPrefix != null && x.JiraId.StartsWith(ownerPrefix)));

            if (!string.IsNullOrWhiteSpace(q))
            {
                var term = q.Trim();
                query = query.Where(x =>
                    x.TalepKonusu.Contains(term) ||
                    (x.MusteriAdi != null && x.MusteriAdi.Contains(term)) ||
                    (x.TakipEden != null && x.TakipEden.Contains(term)));
            }

            if (!string.IsNullOrWhiteSpace(durum))
                query = query.Where(x => x.Durum == durum);

            ViewBag.Q = q;
            ViewBag.Durum = durum;
            return View(await query.OrderByDescending(x => x.OlusturmaTarihi).ToListAsync());
        }

        [HttpGet]
        public async Task<IActionResult> IsDetay(int id)
        {
            if (id <= 0)
                return NotFound();

            var currentUserId = GetCurrentUserId();
            var currentUserName = GetCurrentUserDisplayName();
            var ownerPrefix = GetVposTaskOwnerPrefix(currentUserId);

            var task = await _context.JiraTasks
                .AsNoTracking()
                .Include(x => x.Yorumlar)
                .FirstOrDefaultAsync(x =>
                    x.Id == id &&
                    x.TalepKonusu != null &&
                    x.TalepKonusu.StartsWith(VposTaskPrefix) &&
                    (x.TalepAcan == currentUserName ||
                     (ownerPrefix != null && x.JiraId.StartsWith(ownerPrefix))));

            if (task == null)
                return NotFound();

            return View(task);
        }

        [HttpGet]
        public async Task<IActionResult> YerelHatalar(string? q, string? durum, string? kategori)
        {
            
            var hataIds = GetVposHataIds();
            var query = _context.Hatalar
                .AsNoTracking()
                .Where(x => hataIds.Contains(x.Id));

            if (!string.IsNullOrWhiteSpace(q))
            {
                var term = q.Trim();
                query = query.Where(x =>
                    x.HataAdi.Contains(term) ||
                    x.HataAciklama.Contains(term) ||
                    x.OlusturanKullaniciAdi.Contains(term));
            }

            if (!string.IsNullOrWhiteSpace(durum))
                query = query.Where(x => x.Durum == durum);

            if (!string.IsNullOrWhiteSpace(kategori))
                query = query.Where(x => x.KategoriBilgisi == kategori);

            var data = await query
                .OrderByDescending(x => x.OlusturmaTarihi)
                .ToListAsync();

            var customerIds = data
                .Where(x => x.MusteriID.HasValue)
                .Select(x => x.MusteriID!.Value)
                .Distinct()
                .ToList();

            ViewBag.Musteriler = await _context.Musteriler
                .AsNoTracking()
                .Where(x => customerIds.Contains(x.MusteriID))
                .ToDictionaryAsync(x => x.MusteriID, x => x.Firma ?? $"Customer #{x.MusteriID}");

            ViewBag.Acanlar = await GetVposHataOpenerMapAsync(data);
            ViewBag.Q = q;
            ViewBag.Durum = durum;
            ViewBag.Kategori = kategori;
            ViewBag.Kategoriler = data
                .Select(x => x.KategoriBilgisi)
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Distinct()
                .OrderBy(x => x)
                .ToList();

            return View(data);
        }

        [HttpGet]
        public async Task<IActionResult> HataDetay(int id)
        {
            if (!GetVposHataIds().Contains(id))
                return NotFound();

            var hata = await _context.Hatalar
                .AsNoTracking()
                .FirstOrDefaultAsync(x => x.Id == id);

            if (hata == null)
                return NotFound();

            ViewBag.MusteriAdi = hata.MusteriID.HasValue
                ? await _context.Musteriler
                    .AsNoTracking()
                    .Where(x => x.MusteriID == hata.MusteriID.Value)
                    .Select(x => x.Firma)
                    .FirstOrDefaultAsync()
                : null;

            var openerMap = await GetVposHataOpenerMapAsync(new[] { hata });
            ViewBag.AcanKullanici = openerMap.TryGetValue(hata.Id, out var name) ? name : "-";

            return View(hata);
        }

        [HttpGet]
        public async Task<IActionResult> IsRaporu()
        {
            var currentUserId = GetCurrentUserId();
            var currentUserName = GetCurrentUserDisplayName();
            var ownerPrefix = GetVposTaskOwnerPrefix(currentUserId);

            var rows = await _context.JiraTasks
                .AsNoTracking()
                .Where(x => x.TalepKonusu != null && x.TalepKonusu.StartsWith(VposTaskPrefix))
                .Where(x => x.TalepAcan == currentUserName ||
                            (ownerPrefix != null && x.JiraId.StartsWith(ownerPrefix)))
                .OrderByDescending(x => x.OlusturmaTarihi)
                .ToListAsync();

            var sb = new StringBuilder();
            sb.Append('\uFEFF');
            sb.AppendLine("İş ID;Müşteri;Konu;Talep Açan;Atanan Operasyon;Durum;Tarih");

            foreach (var x in rows)
            {
                sb.AppendLine(string.Join(';', new[]
                {
                    CsvEscape(x.JiraId),
                    CsvEscape(x.MusteriAdi),
                    CsvEscape(CleanTaskSubject(x.TalepKonusu)),
                    CsvEscape(x.TalepAcan),
                    CsvEscape(x.TakipEden),
                    CsvEscape(x.Durum),
                    CsvEscape(x.OlusturmaTarihi.ToString("dd.MM.yyyy HH:mm", CultureInfo.GetCultureInfo("tr-TR")))
                }));
            }

            return File(
                Encoding.UTF8.GetBytes(sb.ToString()),
                "text/csv; charset=utf-8",
                $"VPOS_Entegrasyon_Is_Raporu_{DateTime.Now:yyyyMMdd_HHmm}.csv");
        }

        [HttpGet]
        public async Task<IActionResult> YerelHataRaporu()
        {
            var hataIds = GetVposHataIds();
            var rows = await _context.Hatalar
                .AsNoTracking()
                .Where(x => hataIds.Contains(x.Id))
                .OrderByDescending(x => x.OlusturmaTarihi)
                .ToListAsync();

            var customerIds = rows
                .Where(x => x.MusteriID.HasValue)
                .Select(x => x.MusteriID!.Value)
                .Distinct()
                .ToList();

            var customerMap = await _context.Musteriler
                .AsNoTracking()
                .Where(x => customerIds.Contains(x.MusteriID))
                .ToDictionaryAsync(x => x.MusteriID, x => x.Firma ?? $"Customer #{x.MusteriID}");

            var openedBy = await GetVposHataOpenerMapAsync(rows);

            var sb = new StringBuilder();
            sb.Append('\uFEFF');
            sb.AppendLine("Hata ID;Müşteri;Hata;Açıklama;Kategori;Açan VPOS Kullanıcısı;Atanan Operasyon;Durum;Tarih");

            foreach (var x in rows)
            {
                var customer = x.MusteriID.HasValue && customerMap.TryGetValue(x.MusteriID.Value, out var c)
                    ? c
                    : "-";
                var opener = openedBy.TryGetValue(x.Id, out var o) ? o : "-";

                sb.AppendLine(string.Join(';', new[]
                {
                    x.Id.ToString(CultureInfo.InvariantCulture),
                    CsvEscape(customer),
                    CsvEscape(x.HataAdi),
                    CsvEscape(x.HataAciklama),
                    CsvEscape(x.KategoriBilgisi),
                    CsvEscape(opener),
                    CsvEscape(x.OlusturanKullaniciAdi),
                    CsvEscape(x.Durum),
                    CsvEscape(x.OlusturmaTarihi.ToString("dd.MM.yyyy HH:mm", CultureInfo.GetCultureInfo("tr-TR")))
                }));
            }

            return File(
                Encoding.UTF8.GetBytes(sb.ToString()),
                "text/csv; charset=utf-8",
                $"VPOS_Hata_Raporu_{DateTime.Now:yyyyMMdd_HHmm}.csv");
        }

        private HashSet<int> GetVposHataIds()
        {
            return _context.Parametreler
                .AsNoTracking()
                .Where(x => x.Tur == VposErrorParamType && x.ParAdi != null)
                .Select(x => x.ParAdi!)
                .ToList()
                .Select(x => int.TryParse(x, out var id) ? id : 0)
                .Where(x => x > 0)
                .ToHashSet();
        }

        private HashSet<int> GetVposMusteriIds()
        {
            return _context.Parametreler
                .AsNoTracking()
                .Where(x => x.Tur == VposCustomerParamType && x.ParAdi != null)
                .Select(x => x.ParAdi!)
                .ToList()
                .Select(x => int.TryParse(x, out var id) ? id : 0)
                .Where(x => x > 0)
                .ToHashSet();
        }

        private async Task LoadYeniViewDataAsync()
        {
            var ids = GetVposMusteriIds();
            ViewBag.Musteriler = await _context.Musteriler
                .AsNoTracking()
                .Where(x => ids.Contains(x.MusteriID))
                .OrderBy(x => x.Firma)
                .ToListAsync();
        }

        private async Task LoadYeniMusteriViewDataAsync()
        {
            ViewBag.Durumlar = await GetMusteriDurumlariAsync();
            ViewBag.Teknolojiler = await _context.Parametreler
                .AsNoTracking()
                .Where(x => x.Tur == "Teknoloji" && x.ParAdi != null && x.ParAdi != "")
                .Select(x => x.ParAdi!)
                .Distinct()
                .OrderBy(x => x)
                .ToListAsync();
        }

        private async Task<List<string>> GetMusteriDurumlariAsync()
        {
            return await _context.Parametreler
                .AsNoTracking()
                .Where(x => x.Tur == "Durum" && x.ParAdi != null && x.ParAdi != "")
                .Select(x => x.ParAdi!)
                .Distinct()
                .OrderBy(x => x)
                .ToListAsync();
        }

        private void SaveMusteriEkAlanlariNoSave(int musteriId, string? vkn, string? hariciMusteriId)
        {
            vkn = string.IsNullOrWhiteSpace(vkn) ? null : vkn.Trim();
            hariciMusteriId = string.IsNullOrWhiteSpace(hariciMusteriId) ? null : hariciMusteriId.Trim();
            var prefix = musteriId.ToString(CultureInfo.InvariantCulture) + "|";

            if (vkn != null)
                _context.Parametreler.Add(new Parametre { Tur = MusteriVknParamType, ParAdi = prefix + vkn });

            if (hariciMusteriId != null)
                _context.Parametreler.Add(new Parametre { Tur = MusteriHariciIdParamType, ParAdi = prefix + hariciMusteriId });
        }

        private void SetMusteriEkAlanlariNoSave(int musteriId, string? vkn, string? hariciMusteriId)
        {
            var prefix = musteriId.ToString(CultureInfo.InvariantCulture) + "|";
            var existing = _context.Parametreler
                .Where(x =>
                    (x.Tur == MusteriVknParamType || x.Tur == MusteriHariciIdParamType) &&
                    x.ParAdi != null &&
                    x.ParAdi.StartsWith(prefix))
                .ToList();

            if (existing.Count > 0)
                _context.Parametreler.RemoveRange(existing);

            SaveMusteriEkAlanlariNoSave(musteriId, vkn, hariciMusteriId);
        }

        private (string? Vkn, string? HariciMusteriId) GetMusteriEkAlanlari(int musteriId)
        {
            var prefix = musteriId.ToString(CultureInfo.InvariantCulture) + "|";
            var rows = _context.Parametreler
                .AsNoTracking()
                .Where(x =>
                    (x.Tur == MusteriVknParamType || x.Tur == MusteriHariciIdParamType) &&
                    x.ParAdi != null &&
                    x.ParAdi.StartsWith(prefix))
                .Select(x => new { x.Tur, x.ParAdi })
                .ToList();

            string? vkn = null;
            string? harici = null;

            foreach (var row in rows)
            {
                var value = row.ParAdi![prefix.Length..];
                if (row.Tur == MusteriVknParamType)
                    vkn = value;
                else if (row.Tur == MusteriHariciIdParamType)
                    harici = value;
            }

            return (vkn, harici);
        }

        private async Task<(User? User, int Workload)> GetLeastLoadedOperasyonUserAsync()
        {
            var users = await _context.Users
                .AsNoTracking()
                .Where(x => x.Role == AppRoles.Operasyon)
                .OrderBy(x => x.Id)
                .ToListAsync();

            
            
            if (users.Count == 0)
            {
                users = await _context.Users
                    .AsNoTracking()
                    .Where(x =>
                        x.Role == AppRoles.OperasyonSuperAdmin ||
                        x.Role == "Operasyon Süper Admin" ||
                        x.Role == "Operasyon Super Admin")
                    .OrderBy(x => x.Id)
                    .ToListAsync();
            }

            if (users.Count == 0)
                return (null, 0);

            var aktifIsAtamalari = await _context.JiraTasks
                .AsNoTracking()
                .Where(x => x.TakipEden != null && x.TakipEden != "")
                .Where(x => x.Durum != "Entegrasyon Tamamlandı" &&
                            x.Durum != "Entegrasyon Tamamlanmadı" &&
                            x.Durum != "Tamamlandı" &&
                            x.Durum != "Arşiv")
                .Select(x => x.TakipEden!)
                .ToListAsync();

            var acikHataAtamalari = await _context.Hatalar
                .AsNoTracking()
                .Where(x => x.OlusturanKullaniciAdi != null && x.OlusturanKullaniciAdi != "")
                .Where(x => x.Durum == null || x.Durum != "Kapalı")
                .Select(x => x.OlusturanKullaniciAdi)
                .ToListAsync();

            var workload = users
                .Select(user =>
                {
                    var display = GetDisplayName(user);
                    var aliases = new[] { display, user.UserName }
                        .Where(x => !string.IsNullOrWhiteSpace(x))
                        .Select(x => x.Trim())
                        .Distinct(StringComparer.OrdinalIgnoreCase)
                        .ToArray();

                    var taskCount = aktifIsAtamalari.Count(x => aliases.Contains((x ?? string.Empty).Trim(), StringComparer.OrdinalIgnoreCase));
                    var errorCount = acikHataAtamalari.Count(x => aliases.Contains((x ?? string.Empty).Trim(), StringComparer.OrdinalIgnoreCase));
                    return new { User = user, Count = taskCount + errorCount };
                })
                .OrderBy(x => x.Count)
                .ThenBy(x => x.User.Id)
                .ToList();

            var selected = workload.First();
            return (selected.User, selected.Count);
        }

        private int GetCurrentUserId()
        {
            return int.TryParse(User.FindFirst("UserId")?.Value, out var id) ? id : 0;
        }

        private string GetCurrentUserDisplayName()
        {
            var id = GetCurrentUserId();
            if (id > 0)
            {
                var user = _context.Users
                    .AsNoTracking()
                    .FirstOrDefault(x => x.Id == id);

                if (user != null)
                    return GetDisplayName(user);
            }

            return User.Identity?.Name ?? "VPOS Kullanıcısı";
        }

        private static string GetDisplayName(User user)
        {
            return !string.IsNullOrWhiteSpace(user.FullName)
                ? user.FullName!.Trim()
                : user.UserName.Trim();
        }

        private static string? GetVposTaskOwnerPrefix(int userId)
        {
            return userId > 0 ? $"VPOS-{userId}-" : null;
        }

        private async Task<Dictionary<int, string>> GetVposHataOpenerMapAsync(IEnumerable<Hata> rows)
        {
            var list = rows.ToList();

            
            
            var userIds = list
                .Where(x => x.SecilenHataId.HasValue && x.SecilenHataId.Value < 0)
                .Select(x => -x.SecilenHataId!.Value)
                .Where(x => x > 0)
                .Distinct()
                .ToList();

            var users = await _context.Users
                .AsNoTracking()
                .Where(x => userIds.Contains(x.Id))
                .ToDictionaryAsync(x => x.Id, x => !string.IsNullOrWhiteSpace(x.FullName) ? x.FullName! : x.UserName);

            var result = new Dictionary<int, string>();

            foreach (var hata in list)
            {
                if (hata.SecilenHataId.HasValue && hata.SecilenHataId.Value < 0)
                {
                    var openerId = -hata.SecilenHataId.Value;
                    result[hata.Id] = users.TryGetValue(openerId, out var name) ? name : $"User #{openerId}";
                }
            }

            return result;
        }

        private static string CleanTaskSubject(string? subject)
        {
            var value = (subject ?? string.Empty).Trim();
            return value.StartsWith(VposTaskPrefix, StringComparison.OrdinalIgnoreCase)
                ? value[VposTaskPrefix.Length..].Trim()
                : value;
        }

        private static string CsvEscape(string? value)
        {
            value ??= string.Empty;
            var quote = value.Contains(';') || value.Contains('"') || value.Contains('\n') || value.Contains('\r');
            value = value.Replace("\"", "\"\"");
            return quote ? $"\"{value}\"" : value;
        }
    }
}
